<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 8/15/2017
 * Time: 12:16 PM
 */
defined('BASEPATH') OR exit('No direct script allowed');

class Bnf_admin extends CI_Controller
{
    protected $page;
    public function __construct()
    {
        parent::__construct();
        $this->page='_page';
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model(array('Bnf_admin_model'));
    }
    private function isLogin()
    {

        // return ($this->session->userdata('logged_in') == true)? true : false ;
        if ($this->session->userdata('logged_in')) {
            return true;
        } else {
            return false;
        }
    }

    private function getNotification(){
        $notification['total'] = $this->Bnf_admin_model->getDataTotalRows('id','messages',array('status' =>0),'','');
        $notification['name'] = $this->Bnf_admin_model->getMessgaeLimit('messages',array('status' =>0),'','',5);

        return $notification;
    }
    public function all_message(){
        if($this->isLogin() && $this->session->userdata('user_role') == 1){

                $data['total_rows'] = $this->Bnf_admin_model->getDataTotalRows('id','messages','','','');

                $start = $this->uri->segment(3)?$this->uri->segment(3):0;
                $data['all_data'] = $this->Bnf_admin_model->getData('messages','','id','DESC',10,$start);
                // Pagination Start

                $this->load->library('pagination');

                $config['base_url'] = base_url('admin/message-list');
                $config['total_rows'] =  $data['total_rows'];
                $config['per_page'] = 10;
                $config['uri_segment'] = 3;
                $config['num_links'] = 2;
                $config['full_tag_open'] = "<ul >";
                $config['full_tag_close'] ="</ul>";
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $config['cur_tag_open'] = "<li class='page-active'><a href='#'>";
                $config['cur_tag_close'] = "</a></li>";
                $config['next_tag_open'] = "<li>";
                $config['next_tagl_close'] = "</li>";
                $config['prev_tag_open'] = "<li>";
                $config['prev_tagl_close'] = "</li>";
                $config['first_tag_open'] = '<li>';
                $config['first_tagl_close'] = "&#171;</li>";
                $config['last_tag_open'] = '<li>';
                $config['last_tagl_close'] = "&#187;</li>";

                $this->pagination->initialize($config);
                $data['pagination']= $this->pagination->create_links();
               $data['page_location']='message_list';
                $data['page'] = 'message-list';
                $data['tab_title']='Messages';
                $data['notification'] = $this->getNotification();
                $data['tab'] = 'main';
                // print_r( $data['notification']); exit;
                $this->load->view('admin/dashboard', $data);

        }else{
            redirect('admin/login');
        }
    }

    public function login(){

        if ($this->isLogin()){
          redirect('admin/product');
        } else{
            $this->form_validation->set_rules('username', 'Email', 'trim|required|xss_clean|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
            if($this->form_validation->run() == TRUE) {
                $result = $this->Bnf_admin_model->validateLogin(trim($this->input->post('username')), md5(trim($this->input->post('password'))));
                //  print_r($result); exit;
                if( $result !=false ) {
                    $data['user_id'] = $result->id;
                    $data['name'] = $result->name;
                    $data['email'] = $result->email;
                    $data['user_role'] = $result->user_type;
                    $data['logged_in'] = true;

                    $this->session->set_userdata($data);
                    redirect('admin/product/t-shirt-polo-shirt');
                }else{
                    $this->session->set_flashdata('success','Authentication fail !');
                }
            }
            $this->load->view('admin/login');
        }

    }

    public function index(){
        if($this->isLogin() == true){
            redirect('admin/product/t-shirt-polo-shirt');
        } else{
            redirect('admin/login');
        }
    }

    public function employees(){
        if($this->session->userdata('logged_in') == true){

            //  $data['user_info'] = $this->Admin_model->getDataActiveClientById($this->session->userdata('user_id'));
            // $data['services'] = $this->Admin_model->getDataServiceByIdNew($this->session->userdata('user_id'));
            // clients_avail_service

            $data['body']= 'add_entry';
            $data['tab']='profile';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function checkLoginTime(){
        if($this->input->is_ajax_request() && $this->session->userdata('logged_in') == true){

            $result = $this->Demo_model->getDataRow('login_time','users',array('user_id'=>$this->session->userdata('user_id')));

            $current_time = date("Y-m-d H:i:s");
            $login_time = date('Y-m-d H:i:s',strtotime('+ 10 mins',strtotime($result->login_time)));

            if( $login_time < $current_time){
                echo json_encode(array('msg'=>'expire'));
            } else{
                echo json_encode(array('msg'=>'notexpire'));
            }

        } else{
            echo json_encode(array('msg'=>'not login'));
        }
    }
    public function details($id){
        if($this->session->userdata('logged_in') == true){
            $data['details'] = $this->Demo_model->getDetails('plants_records',array('id'=>$id));
            // print_r( $data['details']); exit();
            $data['admin'] = true;
            $data['body']= 'details';
            $data['tab']='details';
            $data['tab'] = 'main';
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }

    private function getPageId($page_name){
        $menu = array('2'=>'t-shirt-polo-shirt','3'=>'hoodie-jacket','4'=>'trouser-leggings','5'=>'sports-swim-wear','6'=>'kids-baby-wear',
            '7'=>'denim-cargo-pant','8'=>'trouser-overall','9'=>'windbreaker-out-wear',
            '10'=>'shirt-blouse','11'=>'apron-vest','12'=>'sweater','20'=>'home','21'=>'menswear','22'=>'ladieswear','23'=>'kidswear','24'=>'fashionwear',
            '25'=>'sportswear','26'=>'workwear','27'=>'import','29'=>'team','30'=>'contact');

        return array_search($page_name,$menu);
    }
    private function getPageName($page_id){
        $menu = array('2'=>'T-shirt & Polo shirt','3'=>'Hoodie & Jacket','4'=>'Trouser & Leggings','5'=>'Sports & Swim wear',
            '6'=>'Kid\'s & Baby wear','7'=>'Denim & Cargo pant','8'=>'Trouser & Overall - HV','9'=>'Windbreaker & Out wear -HV',
            '10'=>'Shirt & Blouse','11'=>'Apron & Vest','12'=>'Sweater','20'=>'Home','21'=>'Men\'s ','22'=>'Women\'s','23'=>'Kid\'s',
            '24'=>'Fashion','25'=>'Sports','26'=>'Work','27'=>'Import','29'=>'Team','30'=>'Contact');

        return $menu[$page_id];

    }

    public function dashboard($item){
        if($this->isLogin() && $this->session->userdata('user_role') == 1){
            $page_id = $this->getPageId($item);
            if($page_id !==false){
                $data['total_rows'] = $this->Bnf_admin_model->getDataTotal('products',array('page_location'=>$page_id, 'status'=>1),'product_id','DESC');
                $data['tab_title'] = $this->getPageName($page_id);

                $start = $this->uri->segment(4)?$this->uri->segment(4):0;
                $data['all_data'] = $this->Bnf_admin_model->getDataLimit('products',array('page_location'=>$page_id, 'status'=>1),'product_id','DESC',5,$start);
                // Pagination Start

                $this->load->library('pagination');

                $config['base_url'] = base_url('admin/product/'.$item.'/');
                $config['total_rows'] =  $data['total_rows'];
                $config['per_page'] = 5;
                $config['uri_segment'] = 4;
                $config['num_links'] = 2;
                $config['full_tag_open'] = "<ul >";
                $config['full_tag_close'] ="</ul>";
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $config['cur_tag_open'] = "<li class='page-active'><a href='#'>";
                $config['cur_tag_close'] = "</a></li>";
                $config['next_tag_open'] = "<li>";
                $config['next_tag_close'] = "</li>";
                $config['prev_tag_open'] = "<li>";
                $config['prev_tag_close'] = "</li>";
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $data['pagination']= $this->pagination->create_links();
                $data['page_location']=$item;
                $data['page'] = 'home-page';
                $data['tab'] = 'price_quote';
                $data['notification'] = $this->getNotification();
                // print_r( $data['notification']); exit;
                $this->load->view('admin/dashboard', $data);

            }


        }else{
            redirect('admin/login');
        }
    }

    public function dashboard_main($item){
        if($this->isLogin() && $this->session->userdata('user_role') == 1){
            $page_id = $this->getPageId($item);
            if($page_id !==false){
                $data['total_rows'] = $this->Bnf_admin_model->getDataTotal('products',array('page_location'=>$page_id, 'status'=>1),'product_id','DESC');
                $data['tab_title'] = ucfirst($this->getPageName($page_id));

                $start = $this->uri->segment(5)?$this->uri->segment(5):0;
                $data['all_data'] = $this->Bnf_admin_model->getDataLimit('products',array('page_location'=>$page_id, 'status'=>1),'product_id','DESC',5,$start);
                // Pagination Start

                $this->load->library('pagination');

                $config['base_url'] = base_url('admin/main/product/'.$item.'/');
                $config['total_rows'] =  $data['total_rows'];
                $config['per_page'] = 5;
                $config['uri_segment'] = 4;
                $config['num_links'] = 2;
                $config['full_tag_open'] = "<ul >";
                $config['full_tag_close'] ="</ul>";
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $config['cur_tag_open'] = "<li class='page-active'><a href='#'>";
                $config['cur_tag_close'] = "</a></li>";
                $config['next_tag_open'] = "<li>";
                $config['next_tag_close'] = "</li>";
                $config['prev_tag_open'] = "<li>";
                $config['prev_tag_close'] = "</li>";
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $data['pagination']= $this->pagination->create_links();
                $data['page_location']=$item;
                $data['page'] = 'home-page-main';
                $data['tab'] = 'main';
                $data['notification'] = $this->getNotification();
                // print_r( $data['notification']); exit;
                $this->load->view('admin/dashboard', $data);

            }


        }else{
            redirect('admin/login');
        }
    }
    public function team($item=null){
        if($this->isLogin() && $this->session->userdata('user_role') == 1){
            $page_id = $this->getPageId($this->uri->segment(3));
            if($page_id !==false){

                $data['total_rows'] = $this->Bnf_admin_model->getDataTotal('teams',array( 'status'=>1),'id','DESC');
                $data['tab_title'] = ucfirst($this->getPageName($page_id));

                $start = $this->uri->segment(4)?$this->uri->segment(4):0;
                $data['all_data'] = $this->Bnf_admin_model->getDataLimit('teams',array('status'=>1),'id','DESC',5,$start);
                // Pagination Start
                $this->load->library('pagination');

                $config['base_url'] = base_url('admin/main/team');
                $config['total_rows'] =  $data['total_rows'];
                $config['per_page'] = 5;
                $config['uri_segment'] = 4;
                $config['num_links'] = 2;
                $config['full_tag_open'] = "<ul >";
                $config['full_tag_close'] ="</ul>";
                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                $config['cur_tag_open'] = "<li class='page-active'><a href='#'>";
                $config['cur_tag_close'] = "</a></li>";
                $config['next_tag_open'] = "<li>";
                $config['next_tag_close'] = "</li>";
                $config['prev_tag_open'] = "<li>";
                $config['prev_tag_close'] = "</li>";
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';
                $this->pagination->initialize($config);
                $data['pagination']= $this->pagination->create_links();
                $data['page_location']=$this->uri->segment(3);
                $data['page'] = 'team';
                $data['tab'] = 'main';
                $data['notification'] = $this->getNotification();
                // print_r( $data['notification']); exit;
                $this->load->view('admin/dashboard', $data);

            }


        }else{
            redirect('admin/login');
        }
    }
    public function add_product_main(){
        if($this->isLogin()){
            $this->form_validation->set_rules('page_location', 'page location', 'trim|required|xss_clean');
            if (empty($_FILES['picture']['name']))
            {
                $this->form_validation->set_rules('picture', 'product picture', 'required');
            }

            $this->form_validation->set_rules('description', 'product description', 'trim|required|xss_clean');
            if ($this->form_validation->run()) {
                //  echo 'yes'; exit;
                $directory = date('Y-m-d');
                if (!file_exists("assets/product-picture/".$directory )) {
                    mkdir("assets/product-picture/".$directory, 0777);
                }
                $config['upload_path'] = 'assets/product-picture/'.$directory.'/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '2000';
                $config['overwrite'] = TRUE;
                $config['file_name'] = md5(date('Y-m-d H:i:s'));
                $this->load->library('upload', $config);
                if ($this->upload->do_upload('picture')) {
                    $data = array(
                        'page_location' => $this->input->post('page_location'),
                        'product_name' => $this->input->post('name'),
                        'product_image' => $config['upload_path'].'/'.$this->upload->file_name,
                        'product_description' => $this->input->post('description'),
                        'user_id' => $this->session->userdata('user_id'),
                        'date' => date("'Y-m-d H:i:s"),
                        'status' => 1
                    );
                    $result = $this->Bnf_admin_model->dataInsert('products', $data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Product successfully added. Thanks');
                        redirect('admin/main/add-product');
                    }

                }
                else{
                    $data['errors']['image'] = $this->upload->display_errors();
                }
            }

//            $data['bnf_list']= $this->Bnf_admin_model->getData('page_name',array('menu_location' =>'bnf_quote', 'status'=>1),'','');
            $data['main_list']= $this->Bnf_admin_model->getData('page_name',array('menu_location' =>'main', 'status'=>1),'','');
          //  echo $this->db->last_query(); exit;
            $data['tab_title'] = 'Add Product';
            $data['notification'] = $this->getNotification();
            $data['page_location']='add_product';
            $data['page'] = 'add-product-new';
            $data['tab'] = 'main';
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }
    }

    public function addTeamMember(){
        if($this->isLogin()){

            if (empty($_FILES['picture']['name']))
            {
                $this->form_validation->set_rules('picture', 'picture', 'required');
            }

            $this->form_validation->set_rules('name','name','trim|required|xss_clean');
            $this->form_validation->set_rules('designation', 'designation','trim|required|xss_clean');
            $this->form_validation->set_rules('bio', 'bio', 'trim|required|xss_clean');
            if ($this->form_validation->run()) {
                //  echo 'yes'; exit;
                $directory = date('Y-m-d');
                if (!file_exists("assets/teams/".$directory )) {
                    mkdir("assets/teams/".$directory, 0777);
                }
                $config['upload_path'] = 'assets/teams/'.$directory.'/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '2000';
                $config['overwrite'] = TRUE;
                $config['file_name'] = md5(date('Y-m-d H:i:s'));
                $this->load->library('upload', $config);
                if ($this->upload->do_upload('picture')) {
                    $data = array(
                        'name' => $this->input->post('name'),
                        'designation' => $this->input->post('designation'),
                        'image' => $config['upload_path'].'/'.$this->upload->file_name,
                        'bio' => $this->input->post('bio'),
                        'user_id' => $this->session->userdata('user_id'),
                        'added_date' => date("'Y-m-d H:i:s"),
                        'status' => 1
                    );
                    $result = $this->Bnf_admin_model->dataInsert('teams', $data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Team member successfully added. Thanks');
                        redirect('admin/add-member');
                    }

                }
                else{
                    $data['errors']['image'] = $this->upload->display_errors();
                }
            }

            $data['tab_title'] = 'Add Team Member';
            $data['notification'] = $this->getNotification();
            $data['page_location']='team';
            $data['page'] = 'add-team';
            $data['tab'] = 'main';
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }
    }
    public function editTeamMember($id=null){
        if($this->isLogin() && $id !='' && $id !=null){
            $this->form_validation->set_rules('name','name','trim|required|xss_clean');
            $this->form_validation->set_rules('designation', 'designation','trim|required|xss_clean');
            $this->form_validation->set_rules('bio', 'bio', 'trim|required|xss_clean');

            if ($this->form_validation->run()) {
                if(empty($_FILES['picture']['name'])){
                    $data = array(
                        'name' => $this->input->post('name'),
                        'designation' => $this->input->post('designation'),
                        'bio' => $this->input->post('bio'),
                        'user_id' => $this->session->userdata('user_id'),
                        'added_date' => date("'Y-m-d H:i:s"),
                        'status' => 1
                    );

                    $result = $this->Bnf_admin_model->updateInfo('teams',array('id' => $id), $data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Member information successfully updated. Thanks');
                        redirect('admin/main/member-edit/'.$id);
                    }
                } else{
                    $get_url_file = $this->Bnf_admin_model->getDataRow('image','teams', array('id' =>$id ));
                    if(file_exists($get_url_file->image)){
                        unlink($get_url_file->image);
                    }

                    $directory = date('Y-m-d');
                    if (!file_exists("assets/teams/".$directory )) {
                        mkdir("assets/teams/".$directory, 0777);
                    }
                    $config['upload_path'] = 'assets/teams/'.$directory;
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size'] = '2000';
                    $config['overwrite'] = TRUE;
                    $config['file_name'] = md5(date('Y-m-d H:i:s'));
                    $this->load->library('upload', $config);
                    if ($this->upload->do_upload('picture')) {
                        $data = array(
                            'name' => $this->input->post('name'),
                            'designation' => $this->input->post('designation'),
                            'image' => $config['upload_path'].'/'.$this->upload->file_name,
                            'bio' => $this->input->post('bio'),
                            'user_id' => $this->session->userdata('user_id'),
                            'added_date' => date("'Y-m-d H:i:s"),
                            'status' => 1
                        );
                        $result = $this->Bnf_admin_model->updateInfo('teams',array('id' => $id), $data);
                        if($result !=false) {
                            $this->session->set_flashdata('success','Member information successfully updated. Thanks');
                            redirect('admin/main/member-edit/'.$id);
                        }
                    }
                    else{
                        $data['errors']['image'] = $this->upload->display_errors();
                    }

                }

            }

            $data['information']= $this->Bnf_admin_model->getDataRow('*','teams', array('id' =>$id ));
            $data['page_location']='team';
            $data['tab_title'] = 'Edit Member';
            $data['notification'] = $this->getNotification();
            $data['page'] = 'edit-team';
            $data['tab'] = 'main';
            $data['id'] = $id;
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }
    }
    public function deleteTeamMember($id){
        if($this->isLogin() && $id !='' && $id !=null){

            $get_url_file = $this->Bnf_admin_model->getDataRow('image','teams', array('id' =>$id ));
            if(unlink($get_url_file->image)){
                $delete = $this->Bnf_admin_model->deleteData('teams',array('id' =>$id ));
                // echo $this->db->last_query();
                if($delete){
                    redirect('admin/main/team');
                }
            } else{
                redirect('admin/main/team');
            }

        } else{
            redirect('admin/login');
        }
    }

    public function logout(){        // Common pages
        $all=array('user_id','name','email','user_role','logged_in');
        $this->session->set_userdata($all);
        $this->session->sess_destroy();
        redirect('admin/login', 'refresh');
    }
    public function add_product(){
        if($this->isLogin()){
            $this->form_validation->set_rules('page_location', 'page location', 'trim|required|xss_clean');
            if (empty($_FILES['picture']['name']))
            {
                $this->form_validation->set_rules('picture', 'product picture', 'required');
            }
          //  $this->form_validation->set_rules('picture', 'product picture', 'trim|required|xss_clean');
            $this->form_validation->set_rules('name', 'product name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('price', 'product price', 'trim|required|xss_clean');
            $this->form_validation->set_rules('description', 'product description', 'trim|required|xss_clean');
            if ($this->form_validation->run()) {
              //  echo 'yes'; exit;
                $directory = date('Y-m-d');
                if (!file_exists("assets/product-picture/".$directory )) {
                    mkdir("assets/product-picture/".$directory, 0777);
                }
                $config['upload_path'] = 'assets/product-picture/'.$directory.'/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '2000';
                $config['overwrite'] = TRUE;
                $config['file_name'] = md5(date('Y-m-d H:i:s'));
                $this->load->library('upload', $config);
                if ($this->upload->do_upload('picture')) {
                    $data = array(
                        'page_location' => $this->input->post('page_location'),
                        'product_name' => $this->input->post('name'),
                        'product_image' => $config['upload_path'].'/'.$this->upload->file_name,
                        'product_price' => $this->input->post('price'),
                        'product_description' => $this->input->post('description'),
                        'user_id' => $this->session->userdata('user_id'),
                        'date' => date("'Y-m-d H:i:s"),
                        'status' => 1
                    );
                    $result = $this->Bnf_admin_model->dataInsert('products', $data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Product successfully added. Thanks');
                        redirect('admin/add-product');
                    }

                }
                else{
                    $data['errors']['image'] = $this->upload->display_errors();
                }
            }

            $data['bnf_list']= $this->Bnf_admin_model->getData('page_name',array('menu_location' =>'bnf_quote', 'status'=>1),'','');
//            $data['main_list']= $this->Bnf_admin_model->getData('page_name',array('menu_location' =>'main', 'status'=>1),'','');
            $data['tab_title'] = 'Add Product';
            $data['notification'] = $this->getNotification();
            $data['page_location']='add_product';
            $data['page'] = 'add-product';
            $data['tab'] = 'price_quote';
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }
    }

    public function edit_product($product_id){
        if($this->isLogin() && $product_id !='' && $product_id !=null){

            $this->form_validation->set_rules('page_location', 'page location', 'trim|required|xss_clean');
            $this->form_validation->set_rules('name', 'product name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('price', 'product price', 'trim|required|xss_clean');
            $this->form_validation->set_rules('description', 'product description', 'trim|required|xss_clean');
            if ($this->form_validation->run()) {

                if(empty($_FILES['picture']['name'])){
                    $data = array(
                        'page_location' => $this->input->post('page_location'),
                        'product_name' => $this->input->post('name'),
                        'product_price' => $this->input->post('price'),
                        'product_description' => $this->input->post('description'),
                        'user_id' => $this->session->userdata('user_id'),
                    );
                    $result = $this->Bnf_admin_model->updateInfo('products',array('product_id' => $product_id), $data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Product information successfully updated. Thanks');
                        redirect('admin/product-edit/'.$product_id);
                    }
                } else{
                    $get_url_file = $this->Bnf_admin_model->getDataRow('product_image','products', array('product_id' =>$product_id ));
                    if(file_exists($get_url_file->product_image)){
                        unlink($get_url_file->product_image);
                    }
                    $directory = date('Y-m-d');
                    if (!file_exists("assets/product-picture/".$directory )) {
                        mkdir("assets/product-picture/".$directory, 0777);
                    }
                    $config['upload_path'] = 'assets/product-picture/'.$directory;
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size'] = '2000';
                    $config['overwrite'] = TRUE;
                    $config['file_name'] = md5(date('Y-m-d H:i:s'));
                    $this->load->library('upload', $config);
                    if ($this->upload->do_upload('picture')) {
                        $data = array(
                            'page_location' => $this->input->post('page_location'),
                            'product_name' => $this->input->post('name'),
                            'product_image' => $config['upload_path'].'/'.$this->upload->file_name,
                            'product_price' => $this->input->post('price'),
                            'product_description' => $this->input->post('description'),
                            'user_id' => $this->session->userdata('user_id')
                        );
                        $result = $this->Bnf_admin_model->updateInfo('products',array('product_id' => $product_id), $data);
                        if($result !=false) {
                            $this->session->set_flashdata('success','Product information successfully updated. Thanks');
                            redirect('admin/product-edit/'.$product_id);
                        }
                    }
                    else{
                        $data['errors']['image'] = $this->upload->display_errors();
                    }
                }

            }

            $data['bnf_list']= $this->Bnf_admin_model->getData('page_name',array('menu_location' =>'bnf_quote', 'status'=>1),'','');
            $data['information']= $this->Bnf_admin_model->getDataRow('*','products', array('product_id' =>$product_id ));
            $data['page_location']='edit_product';
            $data['tab_title'] = 'Edit Product';
            $data['notification'] = $this->getNotification();
            $data['page'] = 'edit-product';
            $data['tab'] = 'main';
            $data['product_id'] = $product_id;
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }
    } public function edit_product_main($product_id){
        if($this->isLogin() && $product_id !='' && $product_id !=null){

            $this->form_validation->set_rules('page_location', 'page location', 'trim|required|xss_clean');
            $this->form_validation->set_rules('description', 'product description', 'trim|required|xss_clean');
            if ($this->form_validation->run()) {
                if(empty($_FILES['picture']['name'])){
                    $data = array(
                        'page_location' => $this->input->post('page_location'),
                        'product_name' => $this->input->post('name'),
                        'product_description' => $this->input->post('description'),
                        'user_id' => $this->session->userdata('user_id'),
                    );
                    $result = $this->Bnf_admin_model->updateInfo('products',array('product_id' => $product_id), $data);
                    if($result !=false) {
                        $this->session->set_flashdata('success','Product information successfully updated. Thanks');
                        redirect('admin/main/product-edit/'.$product_id);
                    }
                } else{
                    $get_url_file = $this->Bnf_admin_model->getDataRow('product_image','products', array('product_id' =>$product_id ));
                   if(file_exists($get_url_file->product_image)){
                       unlink($get_url_file->product_image);
                   }

                    $directory = date('Y-m-d');
                    if (!file_exists("assets/product-picture/".$directory )) {
                        mkdir("assets/product-picture/".$directory, 0777);
                    }
                    $config['upload_path'] = 'assets/product-picture/'.$directory;
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size'] = '2000';
                    $config['overwrite'] = TRUE;
                    $config['file_name'] = md5(date('Y-m-d H:i:s'));
                    $this->load->library('upload', $config);
                    if ($this->upload->do_upload('picture')) {
                        $data = array(
                            'page_location' => $this->input->post('page_location'),
                            'product_name' => $this->input->post('name'),
                            'product_image' => $config['upload_path'].'/'.$this->upload->file_name,
                            'product_description' => $this->input->post('description'),
                            'user_id' => $this->session->userdata('user_id')
                        );
                        $result = $this->Bnf_admin_model->updateInfo('products',array('product_id' => $product_id), $data);
                        if($result !=false) {
                            $this->session->set_flashdata('success','Product information successfully updated. Thanks');
                            redirect('admin/product-edit/'.$product_id);
                        }
                    }
                    else{
                        $data['errors']['image'] = $this->upload->display_errors();
                    }

                }

            }

            $data['main_list']= $this->Bnf_admin_model->getData('page_name',array('menu_location' =>'main', 'status'=>1),'','');
            $data['information']= $this->Bnf_admin_model->getDataRow('*','products', array('product_id' =>$product_id ));
            $data['page_location']='edit_product';
            $data['tab_title'] = 'Edit Product';
            $data['notification'] = $this->getNotification();
            $data['page'] = 'edit-product-main';
            $data['tab'] = 'main';
            $data['product_id'] = $product_id;
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }
    }

    public function delete_product($location,$product_id){
        if($this->isLogin() && $product_id !='' && $product_id !=null){

            $get_url_file = $this->Bnf_admin_model->getDataRow('product_image','products', array('product_id' =>$product_id ));
            if(unlink($get_url_file->product_image)){
                $delete = $this->Bnf_admin_model->deleteData('products',array('product_id' =>$product_id ));
                // echo $this->db->last_query();
                if($delete){
                    redirect('admin/product/'.$location);
                }
            } else{
                redirect('admin/product/'.$location);
            }

        } else{
            redirect('admin/login');
        }
    }

    public function submitEntry(){
        if($this->isLogin()){

            $this->form_validation->set_rules('date', 'Date', 'trim|required|xss_clean|min_length[3]');
            $this->form_validation->set_rules('plant', 'Plant', 'trim|required|xss_clean');
            $this->form_validation->set_rules('ro', 'Ro\'s', 'trim|required|xss_clean');
            $this->form_validation->set_rules('inspection_time', 'Inspection time', 'trim|required|xss_clean');
            $this->form_validation->set_rules('category', 'Check option', 'trim|required|xss_clean|min_length[5]');
            $this->form_validation->set_rules('kws', 'Main Kws Totalizer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('degc', 'VFD Temp', 'trim|required|xss_clean');
            $this->form_validation->set_rules('run_hour', 'Run Hours', 'trim|required|xss_clean');
            $this->form_validation->set_rules('vfd_speed', 'VFD Speed', 'trim|required|xss_clean');
            $this->form_validation->set_rules('vfd_kw', 'VFD KW', 'trim|required|xss_clean');
            $this->form_validation->set_rules('vfd_volts', 'VFD Volts', 'trim|required|xss_clean');
            $this->form_validation->set_rules('vfd_amp', 'VFD Amps', 'trim|required|xss_clean');

            if ($this->form_validation->run()) {
                /// $package_details=$this->Admin_model->getUserData('package_tbl',array('package_id'=>$this->input->post('package')));
                //print_r($package_details); exit;
                $reg_time=date('Y-m-d H:i:s');
                $data=array(
                    'employee_id' =>$this->session->userdata('user_id'),
                    'date'=>$this->input->post('date'),
                    'plant'=>trim($this->input->post('plant')),
                    'ro'=>$this->input->post('ro'),
                    'inspection_time'=>$this->input->post('inspection_time'),
                    'category'=>$this->input->post('category'),
                    'kws'=>$this->input->post('kws'),
                    'degc'=>$this->input->post('degc'),
                    'run_hour'=>$this->input->post('run_hour'),
                    'vfd_speed'=>$this->input->post('vfd_speed'),
                    'vfd_kw'=>$this->input->post('vfd_kw'),
                    'vfd_volts'=>$this->input->post('vfd_volts'),
                    'vfd_amp'=>$this->input->post('vfd_amp'),
                    'status'=>1,
                    'added_date_time'=>$reg_time
                );
                $result = $this->Demo_model->dataInsert('plants_records',$data);
                if($result !=false) {
                    $this->session->set_flashdata('registration_success','Data Succesfully stored. Thanks');
                    redirect('employees');
                }
            }

            $data['body']= 'add_entry';
            $data['tab']='profile';
            $data['notification'] = $this->getNotification();
            $this->load->view('general/header');
            $this->load->view('general/left-menu',$data);
            $this->load->view('body/main', $data);
            $this->load->view('general/footer');
        } else{
            redirect('login');
        }
    }
    public function change_password(){

        if($this->isLogin()){
            //  $this->load->view('body/dashboard');
            $this->form_validation->set_rules('old_password', 'Old Password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('new_password', 'New password', 'trim|required|xss_clean|min_length[5]|max_length[15]');
            $this->form_validation->set_rules('re_password', 'Confirm password', 'trim|required|xss_clean|matches[new_password]');
            if ($this->form_validation->run()) {
                $user_id=$this->session->userdata('user_id');

                $check_password=$this->Bnf_admin_model->checkPassword('user', array('id' =>$user_id ,'password' => md5(trim($this->input->post('old_password')))));
                if($check_password == true){
                    $data=array(
                        'password' => md5(trim($this->input->post('new_password')))
                    );
                    $result = $this->Bnf_admin_model->updateInfo('user',array('id' =>$user_id ),$data);
                    // echo $this->db->last_query(); exit;
                    if($result == true) {
                        // $this->sendEmail($this->input->post('email'), $data,'email/email-notification');
                        $this->session->set_flashdata('success','Password successfully changed.');
                        redirect('admin/logout');
                    }
                } else{
                    $this->session->set_flashdata('fail','Existing password does not match ');
                    redirect('admin/change-password');
                }

            }

            $data['tab_title'] = 'Change Password';
            $data['tab'] = 'price_quote';
            $data['notification'] = $this->getNotification();
            $data['page_location']='change_password';
            $data['tab_title'] = 'Change Password';
            $data['page'] = 'change-password';
            $this->load->view('admin/dashboard', $data);
        } else{
            redirect('admin/login');
        }

    }
    public function message_delete($id=null){
        if($this->isLogin() && $id !='' && $id !=null){
            $delete = $this->Bnf_admin_model->deleteData('messages',array('id' => $id));
            redirect('admin/message-list');

        } else{
            redirect('admin/login');
        }
    }
    public function view_message($id=null){
        if($this->isLogin() && $id !='' && $id !=null){
           // $delete = $this->Bnf_admin_model->deleteData('messages',array('id' => $id));
            $this->Bnf_admin_model->updateInfo('messages',array('id' =>$id ), array('status' => 1));
            $data['message']= $this->Bnf_admin_model->getDataRow('*','messages', array('id' =>$id ));
            $data['page_location']='';
            $data['tab_title'] = 'Edit Product';
            $data['notification'] = $this->getNotification();
            $data['page'] = 'view_message';
            $data['tab'] = 'main';
            $data['product_id'] = $id;
            $this->load->view('admin/dashboard', $data);

        } else{
            redirect('admin/login');
        }
    }

}