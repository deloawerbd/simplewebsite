<?php
defined('BASEPATH') OR exit('No direct script allowed');
/**
 * Created by PhpStorm.
 * User: User
 * Date: 8/2/2017
 * Time: 9:35 AM
 */
class Bonamibd_application extends CI_Controller{
    protected $page;
    public function __construct()
    {
        parent::__construct();
        $this->page='_page';
        date_default_timezone_set("Asia/Kolkata");
        $this->load->model(array('Bnf_admin_model'));
    }

    public function index(){
        $data['slider_show'] = true;
        $data['products']=$this->Bnf_admin_model->getDataLimitData('products',array('page_location'=>20),'product_id','DESC',16);
        $this->load->view('common/header', $data);
        $this->load->view('body/home'.$this->page."_new", $data);
        $this->load->view('common/footer', $data);
    }

    public function about_us(){
        $data['slider_show'] = false;
        $this->load->view('common/header', $data);
        $this->load->view('body/about_us'.$this->page, $data);
        $this->load->view('common/footer', $data);
    }

    public function contact_us(){
        error_reporting(0);
        // $data['slider_show'] = false;
        $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|xss_clean');
        $this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
        $this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');

        if ($this->form_validation->run()) {
            $data=array(
                'name'=>$this->input->post('name'),
                'email'=>$this->input->post('email'),
                'mobile'=>$this->input->post('mobile'),
                'subject'=>$this->input->post('subject'),
                'message'=>$this->input->post('message'),
                'date_added' => date('Y-m-d H:i:s'),
                'status'=>0
            );
            $this->Bnf_admin_model->dataInsert('messages',$data);
            $send = $this->sendEmail($data,'pobittro.diucse@gmail.com');
            // $send =false;
            if($send ===TRUE){
                $this->session->set_flashdata('success','Successfully submit your message');
                redirect('contact');
            }
        }
        $data['slider_show'] = false;
        $this->load->view('common/header', $data);
        $this->load->view('body/contact'.$this->page, $data);
        $this->load->view('common/footer', $data);
    }

    public function our_team(){
        $data['slider_show'] = false;
        $data['teams']=$this->Bnf_admin_model->getDataLimitData('teams',array('status'=> 1),'id','ASC',16);
        $this->load->view('common/header', $data);
        $this->load->view('body/team'.$this->page, $data);
        $this->load->view('common/footer', $data);
    }


    public function testMail(){
        $this->sendEmail(array('date_added'=>date('Y-m-d'),'client_name'=>'Deloawer','email'=>'pobittro.diucse@gmail.com','mobile'=>'01717999410'),'pobittro.diucse@gmail.com');
    }


    private function sendEmail($data,$email){
        $this->load->library('email');
        $config = array();
        $config['useragent']           = "CodeIgniter";
        $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
        $config['protocol']            = "IMAP";
        // $config['smtp_host']           = "localhost";
        $config['smtp_host']           = "mail.bonamibd.com";
        $config['smtp_user']           = "bonamibdcontact@bonamibd.com";
        $config['smtp_pass']           = "xg$JDQ-)V2(!";
        $config['smtp_port']           = 143;
        //   $config['smtp_port']           = "465";
        $config['mailtype'] = 'html';
        $config['charset']  = 'utf-8';
        $config['newline']  = "\r\n";
        $config['wordwrap'] = TRUE;
        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        $this->email->from('bonamibdcontact@bonamibd.com', 'BONAMI BD');
      //  $this->email->to('faisal.hkwl@gmail.com');
        $this->email->to('deloawer.cse.ju@gmail.com, info@bonamibd.com, bonamibd@hotmail.com, faisal.hkwl@gmail.com');
        $this->email->reply_to($data['email'], $data['name']);
        $msg= $this->load->view('email/email',$data,true);
        $this->email->subject($data['subject']);

        $this->email->message($msg);
        if($this->email->send())
        {
            return true;
        }
        else
        {
            return false;
        }

    }
    

    private function get_category($directory){
        $returndata=array();
        switch ($directory){
            case 'menswear':
                $returndata=array('product_category' => 'Men\'s wear', 'price_display'=>false, 'product_code'=>'BNF-MN-','page_id'=>21);
                break;
            case 'ladieswear':
                $returndata=array('product_category' => 'Women\'s wear', 'price_display'=>false, 'product_code'=>'BNF-WMN-','page_id'=>22);
                break;
            case 'kidswear':
                $returndata=array('product_category' => 'Kid\'s & Baby wear', 'price_display'=>false, 'product_code'=>'BNF-KDS-','page_id'=>23);
                break;

            case 'fashionwear':
                $returndata=array('product_category' => 'Fashion', 'price_display'=>false, 'product_code'=>'BNF-FSN-','page_id'=>24);
                break;
            case 'sportswear':
                $returndata=array('product_category' => 'Sports & Swim wear', 'price_display'=>false, 'product_code'=>'BNF-SRTS-','page_id'=>25);
                break;

            case 'workwear':
                $returndata=array('product_category' => 'Work wear', 'price_display'=>false, 'product_code'=>'BNF-WWR-','page_id'=>26);
                break;
            case 'import':
                $returndata=array('product_category' => 'Import gallery', 'price_display'=>false, 'product_code'=>'BNF-IMPRT-','page_id'=>27);
                break;
            case 't-shirt-polo-shirt':
                $returndata=array('product_category' => 'T-shirt & Polo shirt', 'price_display'=>true, 'product_code'=>'','page_id'=>2);
                break;
            case 'trouser-leggings':
                $returndata=array('product_category' => 'Trouser & Leggings', 'price_display'=>true, 'product_code'=>'','page_id'=>4);
                break;
            case 'hoodie-jacket':
                $returndata=array('product_category' => 'Hoodie & Jacket', 'price_display'=>true, 'product_code'=>'','page_id'=>3);
                break;

            case 'sports-swim-wear':
                $returndata=array('product_category' => 'Sports & Swim wear', 'price_display'=>false, 'product_code'=>'BNF-SRTS-','page_id'=>5);
                break;

            case 'kids-baby-wear':
                $returndata=array('product_category' => 'Kid\'s & Baby wear', 'price_display'=>false, 'product_code'=>'BNF-SRTS-','page_id'=>6);
                break;
            case 'denim-cargo-pant':
                $returndata=array('product_category' => 'Denim & Cargo pant', 'price_display'=>false, 'product_code'=>'BNF-DNMCR-','page_id'=>7);
                break;

            case 'trouser-overall-hv':
                $returndata=array('product_category' => 'Trouser & Overall - HV', 'price_display'=>true, 'product_code'=>'','page_id'=>8);
                break;
            case 'windbreaker-out-wear':
                $returndata=array('product_category' => 'Windbreaker & Out wear -HV', 'price_display'=>true, 'product_code'=>'','page_id'=>9);
                break;
            case 'shirt-blouse':
                $returndata=array('product_category' => 'Shirt & Blouse', 'price_display'=>true, 'product_code'=>'','page_id'=>10);
                break;
            case 'apron-vest':
                $returndata=array('product_category' => 'Apron', 'price_display'=>true, 'product_code'=>'','page_id'=>11);
                break;
            case 'sweater':
                $returndata=array('product_category' => 'Sweater', 'price_display'=>true, 'product_code'=>'','page_id'=>12);
                break;


        }
        return $returndata;
    }

    public function products($directory){
        $data['slider_show'] = false;
        $data['directory'] = $directory;
        $data['options'] = $this->get_category($directory);
        $data['products']=$this->Bnf_admin_model->getDataLimitData('products',array('page_location'=> $data['options']['page_id']),'product_id','DESC',16);
        $this->load->view('common/header', $data);
        $this->load->view('body/product'.$this->page, $data);
        $this->load->view('common/footer', $data);
    }
}