<?php
class Bnf_admin_model extends CI_Model{

    function validateLogin($username,$password) {
        $this-> db -> select('*');
        $this-> db -> from('user');
        $this-> db -> where('email', $username);
        $this-> db -> where('password', $password);
        $this-> db -> where('user_status', 'active');
        $query = $this -> db -> get();
        return ($query->num_rows() > 0) ? $query->row(): false;

    }
    public function dataInsert($table,$info){
        $this->db->insert($table,$info);
        if($this->db->affected_rows()>0){
            return $this->db->insert_id();
        } else{
            return false;
        }
    }

    public function getData($table, $where=null,$order_by=null,$sequence){
        $this->db->select('*');

        if($order_by !=null){
            $this->db->order_by($order_by,$sequence);
        }

        if($where !=null){
            //$limit->db->limit();
            $result=$this->db->get_where($table,$where);
        }else{
            $result=$this->db->get($table);
        }

        if($result->num_rows()>0){
            return $result->result();
        } else{
            return false;
        }
    }
    public function getDataTotal($table,$where=null,$order_by=null,$sequence){
        if($table=='teams'){
            $this->db->select('id');
        } else{
            $this->db->select('product_id');
        }

        if($order_by !=null){
            $this->db->order_by($order_by,$sequence);
        }

        if($where !=null){
            //$limit->db->limit();
            $result=$this->db->get_where($table,$where);
        }else{
            $result=$this->db->get($table);
        }

        if($result->num_rows()>0){
            return $result->num_rows();
        } else{
            return false;
        }
    }

    public function getDataTotalRows($select,$table, $where=null,$order_by=null,$sequence){
        $this->db->select($select);

        if($order_by !=null){
            $this->db->order_by($order_by,$sequence);
        }

        if($where !=null){
            //$limit->db->limit();
            $result=$this->db->get_where($table,$where);
        }else{
            $result=$this->db->get($table);
        }

        if($result->num_rows()>0){
            return $result->num_rows();
        } else{
            return false;
        }
    }

    public function getDataLimit($table, $where=null,$order_by=null,$sequence,$limit,$start){
        $this->db->select('*');

        if($order_by !=null){
            $this->db->order_by($order_by,$sequence);
        }
        $this->db->limit($limit,$start);
        $result=$this->db->get_where($table,$where);

        if($result->num_rows()>0){
            return $result->result();
        } else{
            return false;
        }
    }

    public function getDataLimitData($table, $where=null,$order_by=null,$sequence,$limit){
        $this->db->select('*');

        if($order_by !=null){
            $this->db->order_by($order_by,$sequence);
        }
        $this->db->limit($limit);
        $result=$this->db->get_where($table,$where);

        if($result->num_rows()>0){
            return $result->result_array();
        } else{
            return false;
        }
    }

    public function getMessgaeLimit($table, $where=null,$order_by=null,$sequence,$limit){
        $this->db->select('*');

        if($order_by !=null){
            $this->db->order_by($order_by,$sequence);
        }
        $this->db->limit($limit);
        $result=$this->db->get_where($table,$where);

        if($result->num_rows()>0){
            return $result->result();
        } else{
            return false;
        }
    }

    public function getDetails($table, $where){
        $this->db->select('*');
        $result= $this->db->get_where($table, $where);
        if($result->num_rows() >0 ){
            return $result->row();
        } else{
            return false;
        }
    }
    public function updateLoginTime($table,$where,$data){
        $this->db->where($where)->update($table,$data);
        return $this->db->affected_rows()>0 ? TRUE: FALSE;
    }

    public function getDataRow($select,$table,$where){
        $result=$this->db->select($select)->where($where)->get($table);
        return $result->row();
    }
    public function deleteData($table,$where){
        $this->db->delete($table,$where);
        return ($this->db->affected_rows()>0)?true:false;
    }
    public function checkPassword($table,$where){
        $query=$this->db->select('*')->get_where($table,$where);
        return ($query->num_rows()>0)?true: false;
    }
    public function updateInfo($table,$where,$info){
        $this->db->where($where)->update($table,$info);
        return ($this->db->affected_rows()>0)?true:false;
    }

}


?>