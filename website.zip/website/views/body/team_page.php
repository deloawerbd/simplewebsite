<div class="team-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="sppb-section-title">

                    <p class="sppb-title-subheading">

                    <ul class="margin-left team-list">
                        <li class=""><i class="glyphicon glyphicon-hand-right"></i>&nbsp;<b class="green-cls">BONAMI BD</b> teams believe in work not flattering word</li>
                        <li class=""><i class="glyphicon glyphicon-hand-right" ></i>&nbsp;Here work is making fun but professional and promising</li>
                        <li class=""><i class="glyphicon glyphicon-hand-right" ></i>&nbsp;We love to see the SMILLING face of our clients and consumers</li>
                    </ul>
                    <h2 class="sppb-title-heading">Some of our team members</h2>
                </div>
            </div>
            <div class="clear"></div>

            <?php
               $counter=0;
                if (sizeof($teams > 0)){
                    for ($i=0;$i<4;$i++){ ?>
                        <div class="row">
                             <?php
                                for ($j=0; $j<4;$j++){ ?>
                                    <div class="col-sm-12 col-md-3 col-lg-3">
                                        <div class="single-team wow fadeInLeft animated" data-wow-duration="400ms" data-wow-delay=".3s" style="visibility: visible; animation-duration: 400ms; animation-delay: 0.3s; animation-name: fadeInLeft;">
                                            <div class="team-thumb">
                                                <img src="<?php echo  base_url($teams[$counter]['image'])?>" alt="">
                                            </div>
                                            <h3><?php echo $teams[$counter]['name'];?><br> <span><?php echo $teams[$counter]['designation'];?></span></h3>
                                            <div class="st-ditele">
                                                <p><?php echo $teams[$counter]['bio'];?></p>

                                            </div>
                                        </div>
                                    </div>
                               <?php $counter++; } ?>
                        </div>
                   <?php }

                } else{ ?>
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <div class="single-team wow fadeInLeft animated" data-wow-duration="400ms" data-wow-delay=".3s" style="visibility: visible; animation-duration: 400ms; animation-delay: 0.3s; animation-name: fadeInLeft;">
                                <div class="st-ditele">
                                    <p>No team member yet</p>
                                </div>
                            </div>
                        </div>
                    </div>
               <?php } ?>
        </div>
    </div>
</div>