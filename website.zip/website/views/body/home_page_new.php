
<!-- Home-3 product area Start -->
<div class="home-3-product-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                <div class="clear"></div>
                <!-- home-3 banner area End -->
                <!-- Health & Beauty-->
                <div class="home3-wrapper">
                    <h6 class="sp-module-title"><span>Our product ranges and feedback world wide</span></h6>
                </div>

                <?php
                $counter = 0;
                if(sizeof($products) > 0){
                    for ($i=0; $i<4;$i++){ ?>
                        <div class="row">
                            <div class="all-new-p">
                                <div class="all-new-single singal-p">

                                    <?php
                                    for ($j=0; $j<4;$j++){ ?>
                                        <div class="col-sm-12 col-md-12 col-lg-12">
                                            <div class="sp-single">
                                                <div class="sp-img-area">
                                                    <img class="first-img" src="<?php echo base_url($products[$counter]['product_image']);?>" alt="" />
                                                    <div class="quick-view-detail">
                                                        <?php echo $products[$counter]['product_description'];?>
                                                    </div>
                                                    <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                </div>
                                                <div class="sp-info-area">
                                                    <div class="product-rating">
                                                        <div class="ratingbox" title=" Rating: 3/5">
                                                            <div style="width:50px" class="stars-orange"></div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <?php $counter++ ; } ?>
                                    <!-- SP-SINGLE Product -->
                                </div>
                            </div>
                        </div>
                    <?php }
                } else{ ?>
                    <div class="row">
                        <div class="all-new-p">
                            <div class="all-new-single singal-p">

                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        No Products yet.
                                    </div>
                                <!-- SP-SINGLE Product -->
                            </div>
                        </div>
                    </div>
              <?php  } ?>



                <!-- all product End -->
            </div>
        </div>
    </div>
</div>
<!-- Home-3 product area End -->
