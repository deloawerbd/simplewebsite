
<!-- Home-3 product area Start -->
<div class="home-3-product-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <!-- home-4 Bestseller Products area start -->
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="all-h3-p-area">
                            <div class="home3-wrapper">
                            </div>
                            <div class="h-3-mobile-area">
                                <div class="mobile-p-button">
                                    <div class="tab-mask">
                                        <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                                            <li class="active"><a href="#bestseller" data-toggle="tab">T-SHIRT</a></li>
                                            <li><a href="#featured" data-toggle="tab">POLO SHIRT</a></li>
                                            <li><a href="#mviewed" data-toggle="tab">BABY ROMPERS</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div id="my-tab-content-mobile" class="tab-content">
                                    <div class="tab-pane active" id="bestseller">
                                        <div class="row">
                                            <div class="all-new-p">
                                                <div class="all-new-single home-4s singal-p">
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-1.jpg" alt="" />
                                                                <div class="quick-view-detail">
                                                                    <a href="javascript:void(0)" class="view-details">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:50px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-2.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-3.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-new">New!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title="">
                                                                        <div style="width:25px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$389.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                                <div class="sp-label-percentage">
                                                                    <span class="sp-PricediscountAmount">-$5.00</span>
                                                                </div>

                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                                <div class="sp-label-percentage">
                                                                    <span class="sp-PricediscountAmount">-$9.00</span>
                                                                </div>

                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$350.00</span>
                                                                    <span class="sp-price main-price">$289.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:50px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/tshirt/item-4.jpg" alt="" />
                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="featured">
                                        <div class="row">
                                            <div class="all-new-p">
                                                <div class="all-new-single singal-p">
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-1.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:50px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-2.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-3.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-new">New!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title="">
                                                                        <div style="width:25px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$389.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                                <div class="sp-label-percentage">
                                                                    <span class="sp-PricediscountAmount">-$5.00</span>
                                                                </div>

                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                                <div class="sp-label-percentage">
                                                                    <span class="sp-PricediscountAmount">-$9.00</span>
                                                                </div>

                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$350.00</span>
                                                                    <span class="sp-price main-price">$289.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:50px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/poloshirt/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="mviewed">
                                        <div class="row">
                                            <div class="all-new-p">
                                                <div class="all-new-single singal-p">
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">

                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-1.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:50px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-2.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-3.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-new">New!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title="">
                                                                        <div style="width:25px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$389.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                                <div class="sp-label-percentage">
                                                                    <span class="sp-PricediscountAmount">-$5.00</span>
                                                                </div>

                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                                <div class="sp-label-percentage">
                                                                    <span class="sp-PricediscountAmount">-$9.00</span>
                                                                </div>

                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$350.00</span>
                                                                    <span class="sp-price main-price">$289.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:50px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- SP-SINGLE Product -->
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="sp-single">
                                                            <div class="sp-img-area">
                                                                <img class="first-img" src="<?php echo base_url()?>assets/product-picture/babyropmers/item-4.jpg" alt="" />

                                                                <div class="quick-view-detail">
                                                                    <a href="#">View Detail</a>
                                                                </div>
                                                            </div>
                                                            <div class="sp-info-area">
                                                                <div class="product-rating">
                                                                    <div class="ratingbox" title=" Rating: 3/5">
                                                                        <div style="width:45px" class="stars-orange"></div>
                                                                    </div>
                                                                </div>
                                                                <p class="all-prices">
                                                                    <span class="sp-price price-lessprice">$250.00</span>
                                                                    <span class="sp-price main-price">$189.00</span>
                                                                </p>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- home-34 Bestseller Products area End -->


                <div class="clear"></div>
                <!-- home-3 banner area start -->
                <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                    <li class="active"><a href="" data-toggle="tab">TOP SELL</a></li>
                </ul>

                <div class="row">
                    <div class="banner-wrapper-home3">

                        <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                            <div class="hom-3-bnner">
                                <!-- bannar-1 -->
                                <div class="banner-home-inner">
                                    <a href="#">
                                        <img src="<?php echo base_url()?>assets/product-picture/top/item-1.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div class="hom-3-bnner">
                                <!-- bannar-1 -->
                                <div class="banner-home-inner">
                                    <a href="#">
                                        <img src="<?php echo base_url()?>assets/product-picture/top/item-2.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                            <div class="hom-3-bnner">
                                <!-- bannar-1 -->
                                <div class="banner-home-inner">
                                    <a href="#">
                                        <img src="<?php echo base_url()?>assets/product-picture/top/item-3.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="hom-3-bnner inner-footer">
                                <!-- bannar-1 -->
                                <div class="banner-home-inner">
                                    <a href="#">
                                        <img src="<?php echo base_url()?>assets/product-picture/top/item-4.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- home-3 banner area End -->
                <!-- Health & Beauty-->
                <div class="home3-wrapper">
                    <h3 class="sp-module-title"><span>FLEECE JACKET</span></h3>
                </div>
                <div class="row">
                    <div class="all-new-p">
                        <div class="all-new-single singal-p">
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-1.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-2.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-3.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-new">New!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title="">
                                                <div style="width:25px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$389.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$5.00</span>
                                        </div>

                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$9.00</span>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$350.00</span>
                                            <span class="sp-price main-price">$289.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fleecejacket/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Fashion & accessory -->
                <div class="home3-wrapper">
                    <h3 class="sp-module-title"><span>FASHION</span></h3>
                </div>
                <div class="row">
                    <div class="all-new-p">
                        <div class="all-new-single singal-p">
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-1.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-2.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-3.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-new">New!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title="">
                                                <div style="width:25px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$389.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$5.00</span>
                                        </div>

                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-5.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$9.00</span>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$350.00</span>
                                            <span class="sp-price main-price">$289.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-6.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/fashionwear/item-7.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Toys & Gifts -->
                <div class="home3-wrapper">
                    <h3 class="sp-module-title"><span>MENS WEAR</span></h3>
                </div>
                <div class="row">
                    <div class="all-new-p">
                        <div class="all-new-single singal-p">
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">

                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-1.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-2.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-3.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-new">New!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title="">
                                                <div style="width:25px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$389.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$5.00</span>
                                        </div>

                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-5.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$9.00</span>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$350.00</span>
                                            <span class="sp-price main-price">$289.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-6.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/menswear/item-7.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Fashion & accessory -->
                <div class="home3-wrapper">
                    <h3 class="sp-module-title"><span>SPORTS WEAR</span></h3>
                </div>
                <div class="row">
                    <div class="all-new-p">
                        <div class="all-new-single singal-p">
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">

                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-1.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-2.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-3.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-new">New!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title="">
                                                <div style="width:25px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$389.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-4.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$5.00</span>
                                        </div>

                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-5.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                        <div class="sp-label-percentage">
                                            <span class="sp-PricediscountAmount">-$9.00</span>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$350.00</span>
                                            <span class="sp-price main-price">$289.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-6.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                        <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:50px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!-- SP-SINGLE Product -->
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="sp-single">
                                    <div class="sp-img-area">
                                        <img class="first-img" src="<?php echo base_url()?>assets/product-picture/sportswear/item-7.jpg" alt="" />

                                        <div class="quick-view-detail">
                                            <a href="#">View Detail</a>
                                        </div>
                                    </div>
                                    <div class="sp-info-area">
                                        <div class="product-rating">
                                            <div class="ratingbox" title=" Rating: 3/5">
                                                <div style="width:45px" class="stars-orange"></div>
                                            </div>
                                        </div>
                                        <p class="all-prices">
                                            <span class="sp-price price-lessprice">$250.00</span>
                                            <span class="sp-price main-price">$189.00</span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- all product End -->
            </div>
        </div>
    </div>
</div>
<!-- Home-3 product area End -->
