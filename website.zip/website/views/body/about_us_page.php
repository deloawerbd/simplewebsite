<div class="Page-content-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">GREETINGS FROM  <b class="green-cls">BONAMI BD</b>. <b class="red-cls" >GLOBAL FASHION</b></h6>
                        <div class="sppb-addon-content">
                            <p>We being  garments exporter ,manufacturer and sourcing company  in Bangladesh having  shareholder of a Knit Manufacturer unit  have capability and capacity to deliver Apparels all over the world . </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">INTRODUCTION OF COMPAMY</h6>
                        <div class="sppb-addon-content">
                            <p><b class="green-cls">BONAMI BD</b>. <b class="red-cls" >Global Fashion</b> Established in 2009 is working as a buying house, manufacturer and sourcing company with more than 12 years of experience in garments industry . Our experienced merchandisers and quality assurance/control team are playing the central role to ensure the qualities , shipment schedule and others essential communication with customer 24 hours .</p>
                            <p>Our manufacturing units are  certified with BSCI , Oekotex, Sedex and ACCORD .We always  keep the standard of REACH and others norms in every stage of our production .</p>
                            <p>Our main concern is to make sure that the product purchased and released for shipment conforms with the buyers requirements. Some of our major activities are to make sure of the quality control of raw materials including accessories, care labels, printings and fabric and ensuring competitive prices. To provide total customer satisfaction by providing buyers a range of good quality garments and services at a very reasonable cost is our main objective.</p>
                            <p>We are always ready to take the challenge of buyers demand for all sort of high quality garments as per buyer’s requirement. We welcome customers from all over the world, and in return allow us to prove that <b class="green-cls">BONAMI BD</b> can be your best sourcing company. </p>
                            <p>We always keep our promises to establish a good and long term business relationship to our customers.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">KEY POINT OF COMPANY</h6>
                        <div class="sppb-addon-content">
                            <ul class="margin-left">
                                <li class=""><i class="glyphicon glyphicon-hand-right"></i> Quick price quotation that reflects the best relationship between price and quality. </li>
                                <li class=""><i class="glyphicon glyphicon-hand-right" ></i> Quick Sample development and free sample service. </li>
                                <li class=""><i class="glyphicon glyphicon-hand-right" ></i> Source the Reliable and Integrated Factories that meet the highest standards of ethics and compliance .</li>
                                <li class=""><i class="glyphicon glyphicon-hand-right" ></i> Keep the lead time that get product to customer at the right speed on time.</li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">PRODUCT RANGES</h6>
                        <div class="sppb-addon-content">
                            <p> <b>KNIT ITEMS :</b> T- shirt, Polo short, Sweat shirt, Fleece jacket, Hoodie Trouser, Paijama, Under wear ,Boxer ,  swim wear , leggings, Baby rompers, Baby bibs & so on.</p>
                            <p> <b>WOVEN ITEM :</b> Woven shirt, blouse, Apron, Overall, Denim pant, twill pant, cargo shorts and uniforms.</p>
                            <p> <b> SWEATER :</b> Pullover, Cardigan, Sweater and others.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">PRODUCTION CAPACITY</h6>
                        <div class="sppb-addon-content">
                            <p>We are able to export 600000 pcs T- shirt , 200000 pcs polo shirt, 150000 pcs woven shirt/pant , 1500000 pcs  Sweat-Jacket, 100000 pcs sweater  round the year.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">OWNER SHIP</h6>
                        <div class="sppb-addon-content">
                            <ul class="">
                                <li class="">Sole Proprietor : Safiqul Islam Faisal</li>
                                <li class="">E-mail:info@bonamibd.com/bonamibd@gmail.com</li>
                                <li class="">Cell : +8801874-535340/Whats'app:+8801716-331122,</li>
                                <li class="">Web site :www.bonamibd.com / Skype : boinami33</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">SERVICES</h6>
                        <div class="sppb-addon-content">
                          <p><b class="green-cls">BONAMI BD</b> is able to handle all types of Sports, Casual, Promotional, Work wear & Fashion wear having composition of 100% Cotton, Viscose ,Organic ,Modal, Polyester, Cotton/spandex, cotton –polyester mix and so many fabrics from local and imports .</p>
                          <p>We also conduct final inspection on behalf of the buyer.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">SUPPLIER CREDIBILITY</h6>
                        <div class="sppb-addon-content">
                            <p>Ensure the quality, desired weight, construction and color etc. we evaluate the capacity and capability of every factory. We also check environmental control, safety laws, labor practices and adherence to labor laws. We make sure that our supplier can meet our requirements when it comes to reach the average number of pieces produced as per buyer’s requirement at a given period of time to meet schedule.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">FACTORY SELECTION</h6>
                        <div class="sppb-addon-content">
                            <p> Selection of factory is an important factor in garments merchandising. This task should be perfectly handled, otherwise it will too tough to respect the shipment date of a garment export order. So, during selection of factory/manufacturing units  we follow some key factors as bellow :</p>
                            <ul class="margin-left">
                                <li class="">1. Factory design</li>
                                <li class="">2. Factory equipment & machinery</li>
                                <li class="">3. Factory productivity</li>
                                <li class="">4. Prevalent working procedures</li>
                                <li class="">5. Factory past performance</li>
                                <li class="">6. Technical competency</li>
                                <li class="">7. Factory personnel competency</li>
                                <li class="">8. Financial performance</li>
                                <li class="">9. Factory reputation</li>
                                <li class="">10. Level of professionalism</li>
                                <li class="">11. Legal papers  </li>
                                <li>12. Legal certificate ( BSCI , OEKOTEX , SEDEX and others)</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">FLLOW UP</h6>
                        <div class="sppb-addon-content">
                            <p>Upon placement of orders, we check right away and control the quality of all garment inputs such as yarn, fabric, accessories, labeling and coordinates timing of their procurement and its timely delivery.</p>
                            <p>We let buyers choose and decide what kind of accessories and labels to use as far as style, color, design etc.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">SAMPLE SUPPORT</h6>
                        <div class="sppb-addon-content">
                            <p>We provide FREE sample  after placement of order as per customer  requirement step to step</p>
                            <ul class="margin-left">
                                <li class=""><i class="glyphicon glyphicon-hand-right"></i> Proto / Styling sample</li>
                                <li class=""><i class="glyphicon glyphicon-hand-right"></i> Fitting / Size set sample</li>
                                <li class=""><i class="glyphicon glyphicon-hand-right"></i> Pre-production sample</li>
                                <li class=""><i class="glyphicon glyphicon-hand-right"></i> Production sample</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">QUALITY CONTROL / ASSURANCE</h6>
                        <div class="sppb-addon-content">
                            <p>Our Quality Controllers visit the factory with regular intervals to make sure we meet our buyer’s requirements. Our quality control personnel are stationed at all manufacturing sites to ensure that all production will meet buyer’s requirement. We always want to deliver satisfaction to our customers; we monitor the order from sourcing of raw materials and accessories to production and up to the final shipment of goods. We also monitor and report the status of the order to the buyer with systematic follow up on each and every stage.</p>
                            <p>Only approved goods are packed and buyer is assured of getting quality merchandise. Care is also taken to see whether all packing instructions of the buyer are respected.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <h6 class="ainfo-addon-title">SHIPMENT/CARGO  HANDLING </h6>
                        <div class="sppb-addon-content">
                            <p>All shipping documents are reviewed and verify as to buyers instruction. All cargo is handled by reputable forwarder to obtain correct information regarding ETD and ETA of vessels because time delivery is as important for us as it is to the buyer.</p>
                            <p>Only approved goods are packed and buyer is assured of getting quality merchandise. Care is also taken to see whether all packing instructions of the buyer are respected.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row about-bottom-margin-top" >
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="ap-right wow fadeInRight animated" data-wow-duration="400ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 400ms; animation-delay: 300ms; animation-name: fadeInRight;">
                    <div class="about-us-info">
                        <div class="sppb-addon-content">
                            <p> If you need further more information about the company, please  dont hesiate to contact us. </p>
                            <p>  <b> <i class="glyphicon glyphicon-hand-right"></i> YOU ARE ALWAYS HEARTILY WELCOME TO</b> <b class="green-cls">BONAMI BD</b>. <b class="red-cls" >GLOBAL FASHION</b>
                              </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>