<div class="shop-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="shop--right">
                    <div class="shop-product">

                        <div class="sp-module-content">
                            <ul class="breadcrumb">
                                <li><a href="<?php echo base_url()?>"><i class="fa fa-home"></i></a></li>
                                <li class="active">Product</li>
                                <li class="active"><?php echo $options['product_category'];?></li>
                            </ul>
                        </div>

                        <div class="row">
                            <div class="clear"></div>
                            <div class="singl-shop ">
                                <!-- SP-SINGLE Product -->
                                <?php
                                $counter = 0;
                                if(sizeof($products) > 0){
                                    for ($i=0; $i<4; $i++){ ?>
                                        <div class="row">
                                            <?php  for ($j=0; $j<4; $j++){  ?>
                                                <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                                                    <div class="sp-single">
                                                        <div class="sp-img-area">
                                                            <img class="first-img" height="335" style="height: 335px" src="<?php echo base_url($products[$counter]['product_image']);?>" alt="">
                                                            <div class="quick-view-detail">
                                                                <?php echo  $products[$counter]['product_description'];?>
                                                            </div>
                                                            <?php
                                                            if(in_array($counter,array(3,1,5, 12,13,8))){ ?>
                                                                <div class="sp-label-pro sp-label-pro-new">New!</div>
                                                            <?php } else{ ?>
                                                                <div class="sp-label-pro sp-label-pro-hot">Hot!</div>
                                                            <?php  }
                                                            ?>

                                                        </div>
                                                        <div class="sp-info-area">
                                                            <h2 class="product-name">
                                                                <a title="Dolor Dignissim Semper" href="#">
                                                                    <?php
                                                                    if(isset($options['product_code']) && $options['product_code']!=''){
                                                                        if($counter<10){
                                                                            echo $options['product_code'].'0'.$counter;
                                                                        } else{
                                                                            echo $options['product_code'].$counter;
                                                                        }
                                                                    }
                                                                    ?>
                                                                </a></h2>
                                                            <div class="product-rating">
                                                                <div class="ratingbox" title=" Rating: 3/5">
                                                                    <div style="width:50px" class="stars-orange"></div>

                                                                </div>
                                                            </div>
                                                            <?php

                                                            if( $options['price_display']===FALSE)
                                                            { ?>
                                                                <!--- Price wil not show--->
                                                            <?php } else{ ?>
                                                                <p class="all-prices">
                                                                    <span class="sp-price main-price"><?php echo '$'.$products[$counter]['product_price'];?></span>
                                                                </p>
                                                            <?php }
                                                            ?>


                                                        </div>
                                                    </div>
                                                </div>
                                                <?php $counter++; } ?>

                                        </div>
                                    <?php  }
                                } else{ ?>
                                    <div class="row">
                                        <div class="all-new-p">
                                            <div class="all-new-single singal-p">

                                                <div class="col-sm-12 col-md-12 col-lg-12">
                                                    No Products yet.
                                                </div>
                                                <!-- SP-SINGLE Product -->
                                            </div>
                                        </div>
                                    </div>
                                <?php  } ?>

                            </div>
                            <div class="clear"></div>
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>