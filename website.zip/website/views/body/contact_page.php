<div id="sp-breadcrumb-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12" id="sp-breadcrumb">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <div class="sp-module-content">
                            <ul class="breadcrumb">
                                <li><a href="<?php echo base_url()?>"><i class="fa fa-home"></i></a></li>
                                <li class="active">Contact Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="map-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">

                <div class="map-info-area">
                    <div class="clear"></div>
                    <div class="row ">
                        <div class="col-sm-12 col-md-4 col-lg-4">

                            <?php if($this->session->flashdata('success')){ ?>
                                <div class="form-group my-success" style="color: green;font-weight: bold; text-align: center">
                                    <?php echo $this->session->flashdata('success');
                                    $this->session->unset_userdata('success');
                                    ?>
                                </div>
                            <?php } ?>
                             <h6 class="sppb-addon-title" style="text-align: left">CONTACT  FORM </h6>
                            <div class="contact-p">
                                    <?php echo form_open('contact'); ?>
                                    <input type="text" name="name" placeholder="Name *">
                                    <?php echo form_error('name', '<div class="error">', '</div>'); ?>
                                    <input type="text"  name="email" placeholder="Email *">
                                    <?php echo form_error('email', '<div class="error">', '</div>'); ?>
                                    <input type="text"  name="mobile" placeholder="Mobile *">
                                    <?php echo form_error('mobile', '<div class="error">', '</div>'); ?>
                                    <input type="text" name="subject" placeholder="Subject">
                                    <?php echo form_error('subject', '<div class="error">', '</div>'); ?>
                                    <textarea cols="30" rows="10" name="message" placeholder="Message *"></textarea>
                                    <?php echo form_error('message', '<div class="error error-last">', '</div>'); ?>
                                    <div class="submit control-group">
                                        <div class="controls"><input type="submit" value="Submit" class="btn btn-large btn-primary submit">
                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-3 col-lg-3">
                            <div class="c-right-area">
                                <h6 class="sppb-addon-title">INFORMATION</h6>
                                <div class="sppb-addon-content">
                                    <p><span style="width: 24px;"><em class="fa fa-map-marker" ></em></span>
                                        House : 41, Road : 03, Sector :10 Uttara,
                                       </p>
                                    <p style="margin-left: 30px;"> Dhaka-1230, Bangladesh</p>
                                    <p><span><em class="fa fa-envelope"></em></span> info@bonamibd.com</p>
                                    <p><span><em class="fa fa-phone"></em></span> +8801874535340</p>
                                </div>
                            </div>
                            <div class="c-right-area r-next">
                                <h6 class="sppb-addon-title">BUSINESS HOURS</h6>
                                <p> <b>Monday – Friday </b>: 9am to 20 pm</p>
                                <p> <b>Saturday </b>: 9am to 17pm </p>
                                <p style="color: red"> <b>Sunday</b>: Day off</p>
                                <div class="single-icons">
                                    <ul>
                                        <li><a data-toggle="tooltip" target="_blank" data-placement="top" title="" class="black-tooltip s-1" href="https://www.facebook.com/bonamibdf" data-original-title="Follow us Facebook"><i class="fa fa-facebook"></i> </a></li>
                                        <li><a data-toggle="tooltip" target="_blank"  data-placement="top" title="" class="black-tooltip s-2" href="https://twitter.com/bonami33" data-original-title="Follow us Twitter"><i class="fa fa-twitter"></i></a></li>
                                        <li><a data-toggle="tooltip" target="_blank"  data-placement="top" title="" class="black-tooltip s-3" href="http://bd.linkedin.com/in/bonami" data-original-title="Follow us Google-plus"><i class="fa fa-lg fa-linkedin"></i></a></li>
                                        <li><a data-toggle="tooltip" data-placement="top" title="" class="black-tooltip s-4" href="javascript:void (0)" data-original-title="Follow us Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                        <li><a data-toggle="tooltip" data-placement="top" title="" class="black-tooltip s-5" href="javascript:void (0)" data-original-title="Follow us Behance"><i class="fa fa-behance"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-5 col-lg-5">
                           <div id="mapShow" style="width:100%;height:500px;" ></div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
