<div class="table-content">
    <div class="table-content-header">
        <h3>Label</h3>
        <form class="form-wrapper-02">
            <input id="search" type="text" placeholder="Type search text here..."/>
            <input id="submit" type="submit" value="Search" />
        </form>
    </div>
    <div class="table-content-description">
        <p>The contains list of forums and statistical information about these forums.</p>
        <div class="button">
            <ul>
                <li><a href="#inline_content" class="inline">Create</a></li>
            </ul>
        </div>
    </div>
    <div class="univ-table-container label-table-container display-table">
        <table cellpadding="0" cellspacing="0">
            <thead>
            <th><input type="checkbox"/> Label</th>
            <th>Users</th>
            <th>Topic</th>
            <th>Total Message</th>
            <th>Last 24 Hours</th>
            </thead>
            <tbody>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">Favorite</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">Information Technologys</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">New Forum</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">Science</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">Sports</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">This is my new forum</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            <tr>
                <td><input type="checkbox"/><a href="javascript:;">This should display in the forum list</a></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
            </tr>
            </tbody>
        </table>
        <div class="table-footer">
            <div class="table-footer-child"><span>Number of topics per page</span><input type="text"/><button class="go-button">Go</button></div>
            <div class="table-footer-child">
                <div class="pagination">
                    <ul>
                        <li><a href="javascript:;">&#171;</a></li>
                        <li><a href="javascript:;">1</a></li>
                        <li class="page-active"><a href="javascript:;">2</a></li>
                        <li><a href="javascript:;">3</a></li>
                        <li><a href="javascript:;">4</a></li>
                        <li><a href="javascript:;">5</a></li>
                        <li><a href="javascript:;">&#187;</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>