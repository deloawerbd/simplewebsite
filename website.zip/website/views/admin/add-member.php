<ul>
    <li><a href="<?php echo base_url('admin/add-member')?>" class="inline">Add Team Member</a></li>
</ul>