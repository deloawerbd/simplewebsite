<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>assets/img/favicon-32x32.png">
    <link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/style.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/custome.css" type="text/css"/>
    <link href='http://fonts.googleapis.com/css?family=Hammersmith+One' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/style-responsive.css" type="text/css"/>
    <!--[if gte IE 9]>
    <link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/iestyle.css" type="text/css"  />

    <![endif] -->
    <!--<link rel="stylesheet" href="css/dropdown.css" type="text/css"/>-->
    <script src="<?php echo  base_url()?>assets/admin/internal/scripts/jquery-1.9.1.min.js"></script>
    <!-----MODAL ----->
    <link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/colorbox/colorbox.css" />
    <script src="<?php echo  base_url()?>assets/admin/internal/colorbox/jquery.colorbox.js"></script>
<style type="text/css">
    .page-active>a>span{
        margin-left: 0px;
        margin-right: 0px;
    }
</style>

    <script>
        $(document).ready(function(){
            //Examples of how to assign the Colorbox event to elements

            $(".item").click(function(){
                $('.item').removeClass('tab-active');
                $(this).addClass("tab-active");
                var id = $(this).attr('id');
                if(id=='bnf-bnf-btn'){
                    $("#main-menu-list").hide();
                    $("#bnf-list").show();
                } else{
                    $("#main-menu-list").show();
                    $("#bnf-list").hide();
                }
            });
        });
    </script>


    <!----- END MODAL ----->
    <!--<script src="scripts/bootstrap.min.js"></script>-->

    <title>ADMIN</title>
</head>

<body>
<header>
    <div class="logo-holder">
        <h1>ADMIN</h1>
    </div>
    <div class="menu-tabs">
        <ul>
            <li><span class="close-btn-20" title="Close">Close</span><a title="All Labels"><?php echo isset($tab_title) ? $tab_title:'';?></a></li>
        </ul>
    </div>
    <div class="right-navbar" style="float:right;">
        <nav>
            <ul>
                <li>
                    <a href="<?php echo base_url('admin/message-list')?>">Message
                        <?php
                           if(isset($notification['total']) && $notification['total'] !=0 ){ ?>
                               <div class="notification second-notification"><i><?php echo $notification['total'];?></i></div>
                         <?php  }
                        ?>

                    </a>

                    <?php
                    if(isset($notification['name']) && $notification['name'] !=false){ ?>

                        <ul class="fallback fallback-two">

                            <?php
                               foreach ($notification['name']  as $names){ ?>
                                   <li><a href="<?php echo base_url('admin/view-message/'.$names->id);?>">New Message from <?php echo $names->name;?></a></li>
                              <?php }
                            ?>
                            <li class="notification-active"><a href="<?php echo base_url('admin/message-list')?>">All Notifications</a><div class="notification third-notification"><i><?php echo $notification['total'];?></i></div></li>
                        </ul>
                    <?php  }
                    ?>

                </li>

                <li>
                    <a href="javascript:void(0)"><?php echo ucfirst($this->session->userdata('name'));?></a>
                </li>
                <li class="li-custom">
                    <a href="<?php echo base_url('admin/change-password')?>">Change Password</a>
                </li>
                <li>
                    <a href="<?php echo base_url('admin/logout')?>">Log Out</a>
                </li>
            </ul>
        </nav>
    </div>
</header>


<section>
    <div class="sidebar">
        <?php include ("side_bar.php")?>
    </div>
    <div class="content">

        <?php include($page.'.php')?>

    </div>
</section>

<footer>
    <div class="copyright"><p>Copyright 2013 BONAMIBD Inc. All Rights Reserved</p></div>
    <div class="menu-footer">
        <ul>
            <li><a href="javascript:;">About BONAMI BD</a>
            <li><a href="javascript:;">Terms of Service</a>
            <li><a href="javascript:;">Privacy Policy</a>
            <li><a href="javascript:;">Report a Bug</a>
        </ul>
    </div>
</footer>

<!----- MODAL LIGHTBOX ----->
<div style="display: none">
    <div id='inline_content' class="minimum-colorbox">
        <h1>Delete Confirmation
            <div class="left-button-holder close-holder-button">
                <div class="left-child-button org-close-button"><a href="javascript:;" onclick="$.colorbox.close();" id="close-button"></a></div>
            </div>
        </h1>
        <div class="colorbox-input">
            <label class="error">Are you sure to delete this message ? </label>
        </div>
        <input type="hidden" name="deleted_messade_id" value="" id="deleted_messade_id"/>
        <div class="colorbox-button"><button id="confirm_delete">Confirm</button></div>
    </div>
</div>
<!----- END MODAL LIGHTBOX ----->
<script type="text/javascript">

    $(document).ready(function(){
        $("#confirm_delete").click(function (e) {
            var message_id = $("#deleted_messade_id").val();
           window.location.href="<?php echo base_url('admin/message-deletion/')?>"+message_id;
        });
    });
    function deleteMessage(id) {
        $("#deleted_messade_id").val(id);
        $.colorbox({inline:true, href:".minimum-colorbox"});
    }
</script>
</body>
</html>
