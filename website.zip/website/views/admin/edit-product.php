<link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/form-style.css" type="text/css"  />
<div class="table-content">
    <div class="table-content-header">
    </div>
    <div class="univ-table-container label-table-container display-table">
        <div class="form-style-5 message-box">

                <?php echo form_open_multipart('admin/product-edit/'.$product_id); ?>

                <fieldset>
                    <legend>Edit Product Information</legend>

                    <?php

                    if($this->session->flashdata('success')){ ?>
                        <div class="form-group my-success" style="color: green;font-weight: bold; font-size: 12px; text-align: center"><?php echo $this->session->flashdata('success'); ?> </div>
                        <?php $this->session->unset_userdata('success'); }  ?>


                    <label for="job">Page Location</label>
                    <select id="job" name="page_location" >
                        <optgroup label="BNF QUOTATION">
                            <?php
                            if($bnf_list !=FALSE){
                                foreach ($bnf_list as $bnf_list) { ?>
                                    <option value="<?php echo $bnf_list->id;?>" <?php echo ($bnf_list->id==$information->page_location) ? 'selected':'';?>><?php echo $bnf_list->page_name;?></option>
                                <?php }
                            }
                            ?>
                        </optgroup>
                    </select>
                    <?php echo form_error('page_location', '<div class="adduseradminerror">', '</div>'); ?>
                    <input type="file" name="picture" placeholder="Product Picture">
                    <?php echo form_error('picture', '<div class="adduseradminerror">', '</div>'); ?>
                    <input type="text" name="name" placeholder="Product name" value="<?php echo $information->product_name;?>">
                    <?php echo form_error('name', '<div class="adduseradminerror">', '</div>'); ?>
                    <input type="text" name="price" placeholder="Product price" value="<?php echo $information->product_price;?>">
                    <?php echo form_error('price', '<div class="adduseradminerror">', '</div>'); ?>
                    <textarea  name="description" placeholder="Product description" ><?php echo $information->product_description;?></textarea>
                    <?php echo form_error('description', '<div class="adduseradminerror">', '</div>'); ?>
                </fieldset>
                <input type="submit" class="btn-submit" value="Update Information" />
           <?php echo form_close();?>
        </div>
    </div>
</div>