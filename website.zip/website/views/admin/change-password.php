<link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/form-style.css" type="text/css"  />
<div class="table-content">
    <div class="table-content-header">
    </div>
    <div class="univ-table-container label-table-container display-table">
        <div class="form-style-5 message-box">
                <?php echo form_open('admin/change-password'); ?>

                <?php
                if($this->session->flashdata('fail')){ ?>
                    <div class="form-group my-success" style="color: red;font-weight: bold; font-size: 12px; text-align: center"><?php echo $this->session->flashdata('fail'); ?> </div>
                    <?php $this->session->unset_userdata('fail'); } ?>

                <fieldset>
                    <legend class="form-title">Change Password</legend>
                    <input type="password" name="old_password" placeholder="Old Password">
                    <?php echo form_error('old_password', '<div class="adduseradminerror">', '</div>'); ?>
                    <input type="password" name="new_password" placeholder="New Password">
                    <?php echo form_error('new_password', '<div class="adduseradminerror">', '</div>'); ?>
                    <input type="password" name="re_password" placeholder="Confirm Password">
                    <?php echo form_error('re_password', '<div class="adduseradminerror">', '</div>'); ?>
                </fieldset>
                <input type="submit" class="btn-submit" value="Update Password" />
            <?php echo form_close()?>
        </div>
    </div>
</div>