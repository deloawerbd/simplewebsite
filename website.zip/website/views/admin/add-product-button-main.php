<ul>
    <li><a href="<?php echo base_url('admin/main/add-product')?>" class="inline">Add Product</a></li>
</ul>