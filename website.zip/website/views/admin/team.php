<div class="table-content">
    <div class="table-content-header">
        <h3><?php echo isset($tab_title) ? $tab_title:'';?></h3>
        <?php include("search-product.php")?>

    </div>
    <div class="table-content-description">
        <p>The contains list of team members</strong>.</p>
        <div class="button">
            <?php include("add-member.php")?>
        </div>
    </div>
    <div class="univ-table-container label-table-container display-table">
        <table cellpadding="0" cellspacing="0" class="scroll" >
            <thead>
            <th><input type="checkbox"/>Member Name</th>
            <th>Designation</th>
            <th>Bio</th>
            <th>Picture</th>
            <th>Action</th>
            </thead>
            <tbody>
            <?php
            if(isset($all_data) && $all_data!=false){
                foreach ($all_data as $records){ ?>
                    <tr>
                        <td style="text-align: left !important;"><input type="checkbox"/><a href="javascript:;"><?php echo $records->name;?></a></td>
                        <td><?php echo $records->designation;?></td>
                        <td><?php echo $records->bio;?></td>
                        <td>
                            <img src="<?php echo base_url($records->image)?>" alt="Product Image" width="60" style="margin-top: 2px; margin-bottom: 2px" height="60">
                        </td>
                        <td>
                            <a href="<?php echo base_url('admin/main/member-edit/'.$records->id)?>">
                                <img src="<?php echo base_url()?>assets/img/edit.png"></a> &nbsp;|&nbsp;
                            <a href="<?php echo base_url('admin/main/member-delete/'.$records->id)?>">
                                <img src="<?php echo base_url()?>assets/img/delete.png"></a>
                        </td>
                    </tr>
                <?php  }
            } else{ ?>
                <tr>
                    <td colspan="4"> No record yet.</td>
                </tr>
            <?php  } ?>

            </tbody>
        </table>
        <div class="table-footer">
            <div class="table-footer-child"><span>Total number of Product</span><button class="go-button"><?php echo $total_rows?></button></div>
            <div class="table-footer-child">
                <div class="pagination">
                    <?php echo $pagination;?>
                </div>
            </div>
        </div>
    </div>
</div>