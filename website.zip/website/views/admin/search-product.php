<form class="form-wrapper-02">
    <input id="search" type="text" placeholder="Type search text here..."/>
    <input id="submit" type="submit" value="Search" />
</form>