<link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/form-style.css" type="text/css"  />
<div class="table-content">
    <div class="table-content-header">
    </div>
    <div class="univ-table-container label-table-container display-table" style="margin-top: -30px">
        <div class="form-style-5 message-box">
            <?php echo form_open_multipart('admin/main/member-edit/'.$id); ?>
            <fieldset>
                <legend>Update Member's Information</legend>

                <?php
                if($this->session->flashdata('success')){ ?>
                    <div class="form-group my-success" style="color: green;font-weight: bold; font-size: 12px; text-align: center"><?php echo $this->session->flashdata('success'); ?> </div>
                    <?php $this->session->unset_userdata('success'); }  ?>

                <input type="text" name="name" placeholder="Name" value="<?php echo $information->name;?>" >
                <?php echo form_error('name', '<div class="adduseradminerror">', '</div>'); ?>

                <input type="text" name="designation" placeholder="Designation" value="<?php echo $information->designation;?>" >
                <?php echo form_error('designation', '<div class="adduseradminerror">', '</div>'); ?>

                <input type="file" name="picture" placeholder="Picture">
                <?php echo form_error('picture', '<div class="adduseradminerror">', '</div>'); ?>
                <input type="text" name="bio" placeholder="Bio" value="<?php echo $information->bio;?>">
                <?php echo form_error('bio', '<div class="adduseradminerror">', '</div>'); ?>

            </fieldset>
            <input type="submit" class="btn-submit" value="Update Member" />
            <?php echo form_close();?>
        </div>
    </div>
</div>