<div id="moving_tab">
    <div class="tabs">
        <div class="lava"></div>
        <span class="item <?php echo ($tab=='price_quote') ? 'tab-active':''?>" id="bnf-bnf-btn">BNF QUOTATION</span>
        <span class="item <?php echo ($tab=='main') ? 'tab-active':''?>" id="bnf-main-btn">Main Menu</span>
    </div>
    <div class="content-tab">
        <div class="panel">
            <ul id="bnf-list" style="display: <?php echo ($tab=='price_quote') ? 'block':'none'?>">

                <li class="<?php echo ($page_location=='t-shirt-polo-shirt') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/t-shirt-polo-shirt')?>">T-shirt & Polo shirt</a></li>
                <li class="<?php echo ($page_location=='hoodie-jacket') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/hoodie-jacket')?>">Hoodie & Jacket</a></li>
                <li class="<?php echo ($page_location=='trouser-leggings') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/trouser-leggings')?>">Trouser & Leggings</a></li>
                <li class="<?php echo ($page_location=='sports-swim-wear') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/sports-swim-wear')?>">Sports & Swim wear</a></li>
                <li class="<?php echo ($page_location=='kids-baby-wear') ? 'active':'';?>" ><a href="<?php echo base_url('admin/product/kids-baby-wear')?>">Kid's & Baby wear</a></li>
                <li class="<?php echo ($page_location=='denim-cargo-pant') ? 'active':'';?>" ><a href="<?php echo base_url('admin/product/denim-cargo-pant')?>">Denim & Cargo pant</a></li>
                <li class="<?php echo ($page_location=='trouser-overall') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/trouser-overall')?>">Trouser & Overall</a></li>
                <li class="<?php echo ($page_location=='windbreaker-out-wear') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/windbreaker-out-wear')?>">Windbreaker & Out wear</a></li>
                <li class="<?php echo ($page_location=='shirt-blouse') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/shirt-blouse')?>">Shirt & Blouse</a></li>
                <li class="<?php echo ($page_location=='apron-vest') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/apron-vest')?>">Apron & Vest</a></li>
                <li class="<?php echo ($page_location=='sweater') ? 'active':'';?>"><a href="<?php echo base_url('admin/product/sweater')?>">Sweater</a></li>

            </ul>
            <ul id="main-menu-list" style="display: <?php echo ($tab=='main') ? 'block':'none'?>">
                <li  class="<?php echo ($page_location=='home') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/home')?>">Home</a></li>
                <li class="<?php echo ($page_location=='menswear') ? 'active':'';?>" ><a href="<?php echo base_url('admin/main/product/menswear')?>">Men's</a></li>
                <li class="<?php echo ($page_location=='ladieswear') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/ladieswear')?>">Women's</a></li>
                <li class="<?php echo ($page_location=='kidswear') ? 'active':'';?>" ><a href="<?php echo base_url('admin/main/product/kidswear')?>">Kid's</a></li>
                <li class="<?php echo ($page_location=='fashionwear') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/fashionwear')?>">Fashion</a></li>
                <li class="<?php echo ($page_location=='sportswear') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/sportswear')?>">Sports</a></li>
                <li class="<?php echo ($page_location=='workwear') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/workwear')?>">Work Wear</a></li>
                <li class="<?php echo ($page_location=='import') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/import')?>">Import Gallery</a></li>
<!--                <li class="--><?php //echo ($page_location=='about-us') ? 'active':'';?><!--"><a href="--><?php //echo base_url('admin/main/product/about-us')?><!--" >About Us</a></li>-->
                <li class="<?php echo ($page_location=='team') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/team')?>" >Team</a></li>
                <li class="<?php echo ($page_location=='contact') ? 'active':'';?>"><a href="<?php echo base_url('admin/main/product/contact')?>" >Contact</a></li>
            </ul>
        </div>
    </div>
</div>