<link rel="stylesheet" href="<?php echo  base_url()?>assets/admin/internal/css/form-style.css" type="text/css"  />
<div class="table-content">
    <div class="table-content-header">
    </div>
    <div class="univ-table-container label-table-container display-table" style="margin-top: -30px">
        <div class="form-style-5 message-box" >
            <a href="<?php echo base_url('admin/message-list')?>" class="btn-submit" > <<&nbsp;Back </a>
            <fieldset>
                 <p><?php echo $message->date_added;?> </p>
                 <p>Subject : <?php echo $message->subject;?> </p>
                <br>
                <br>
                 <h4>Dear Mr. Faisal,</h4>
                <br>
                 <p><?php echo $message->message;?> </p>
                <br>
                <p>Sincerely,</p>
                <p><?php echo $message->name;?></p>
                <p><?php echo $message->email;?></p>
                <p><?php echo $message->mobile;?></p>

            </fieldset>

        </div>
    </div>
</div>