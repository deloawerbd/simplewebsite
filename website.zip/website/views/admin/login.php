<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" class="second-index-3-html">
<head>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>assets/img/favicon-32x32.png">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="<?php echo base_url()?>assets/admin/login/css/style.css" type="text/css"/>
    <link href='http://fonts.googleapis.com/css?family=Hammersmith+One|Boogaloo' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo base_url()?>assets/admin/login/css/style-responsive.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo base_url()?>assets/admin/login/css/custome.css" type="text/css"/>
    <title>BONAMI BD | ADMIN</title>
</head>
<header>
    <div class="logo-holder">
        <div class="logo-img"> &nbsp;</div>
        <h1>Admin Panel</h1>
    </div>
</header>
<body>
<div class="wrapper">
    <div class="main-container">
        <?php echo form_open('admin/login')?>
        <div class="main-container-header">
            <div class="header-left"></div>
            <h1><img src="<?php echo base_url()?>assets/admin/login/images/signin-img.png"/> Login to admin panel</h1>
            <div class="header-right"></div>
        </div>
           <?php
           if($this->session->flashdata('success')){ ?>
               <div class="form-group my-success" style="color: red;font-weight: bold; text-align: center"><?php echo $this->session->flashdata('success'); ?> </div>
               <?php $this->session->unset_userdata('success'); }  ?>

        <div class="main-input">
            <div id="username-icon"></div><input name="username" type="text" placeholder="Username"/>
            <?php echo form_error('username', '<div class="adduseradminerror">', '</div>'); ?>
        </div>
        <div class="main-input">
            <div id="lock-icon"></div><input type="password" name="password" placeholder="Password"/>
            <?php echo form_error('password', '<div class="adduseradminerror">', '</div>'); ?>
        </div>

         <button class="signin-button external-button custom-login-button" >Sign In</button>

        <?php echo form_close();?>
    </div>
</div>
</body>
<footer>
    <div class="main-footer">
        <p>&copy; 2017 BONAMI BD</p>
        <div class="nav-footer">
            <ul>
                <li><a href="javascript:;">Terms of Service</a></li>
                <li><a href="javascript:;">Privacy Policy</a></li>
                <li><a href="javascript:;">Report a Bug</a></li>
            </ul>
        </div>
    </div>
</footer>
</html>
