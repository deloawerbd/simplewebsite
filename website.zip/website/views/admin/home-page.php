<div class="table-content">
    <div class="table-content-header">
        <h3><?php echo isset($tab_title) ? $tab_title:'';?></h3>
        <?php include("search-product.php")?>

    </div>
    <div class="table-content-description">
        <p>The contains list of products for <strong><?php echo isset($tab_title) ? $tab_title:'';?></strong>.</p>
        <div class="button">
            <?php include("add-product-button.php")?>
        </div>
    </div>
    <div class="univ-table-container label-table-container display-table">
        <table cellpadding="0" cellspacing="0" class="scroll" >
            <thead>
                <th><input type="checkbox"/> Product Name</th>
                <th>Product Price</th>
                <th>Description</th>
                <th>Picture</th>
                <th>Action</th>
            </thead>
            <tbody>
            <?php
                if(isset($all_data) && $all_data!=false){
                    foreach ($all_data as $records){ ?>
                        <tr>
                            <td><input type="checkbox"/><a style="float:left" href="javascript:;"><?php echo $records->product_name;?></a></td>
                            <td><?php echo $records->product_price;?></td>
                            <td><?php echo $records->product_description;?></td>
                            <td>
                                <img src="<?php echo base_url($records->product_image)?>" alt="Product Image" width="60" style="margin-top: 2px; margin-bottom: 2px" height="60">
                            </td>
                            <td>
                                <a href="<?php echo base_url('admin/product-edit/'.$records->product_id)?>">
                                    <img src="<?php echo base_url()?>assets/img/edit.png"></a> &nbsp;|&nbsp;
                                <a href="<?php echo base_url('admin/product-delete/'.$page_location.'/'.$records->product_id)?>">
                                    <img src="<?php echo base_url()?>assets/img/delete.png"></a>
                            </td>
                        </tr>
                  <?php  }
                } else{ ?>
                    <tr>
                        <td colspan="5"> No record yet.</td>
                    </tr>
              <?php  } ?>

            </tbody>
        </table>
        <div class="table-footer">
            <div class="table-footer-child"><span>Total number of Product</span><button class="go-button"><?php echo $total_rows?></button></div>
            <div class="table-footer-child">
                <div class="pagination">
                    <?php echo $pagination;?>
                </div>
            </div>
        </div>
    </div>
</div>