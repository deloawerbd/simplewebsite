<div class="table-content">
    <div class="table-content-header">
        <h3><?php echo isset($tab_title) ? $tab_title:'';?></h3>
        <?php include("search-product.php")?>

    </div>
    <div class="table-content-description">
        <p>The contains list of <strong><?php echo isset($tab_title) ? $tab_title:'';?></strong>.</p>

    </div>
    <div class="univ-table-container label-table-container display-table">
        <table cellpadding="0" cellspacing="0" class="scroll" >
            <thead>
            <th><input type="checkbox"/>Sender Name</th>
            <th>Message</th>
            <th>Sender Email</th>
            <th>Subject</th>
            <th>Status</th>
            <th>Action</th>
            </thead>
            <tbody>
            <?php
            if(isset($all_data) && $all_data!=false){
                foreach ($all_data as $records){ ?>
                    <tr>
                        <td><input type="checkbox"/><a href="javascript:;"><?php echo $records->name;?></a></td>
                        <td>
                            <?php echo $records->message;?>
                        </td>
                        <td><?php echo $records->email;?></td>
                        <td><?php echo $records->subject;?></td>

                        <td>
                            <?php echo ($records->status ==1)?'Read':'<a href="javascript:void(0)">Unread</a>';?>
                        </td>
                        <td>
                            <a href="<?php echo base_url('admin/view-message/'.$records->id);?>">View</a>&nbsp;|&nbsp;
                            <a href="javascript:;" onclick="deleteMessage(<?php echo $records->id;?>)">Delete</a>
                        </td>
                    </tr>
                <?php  }
            } else{ ?>
                <tr>
                    <td colspan="6"> No record yet.</td>
                </tr>
            <?php  } ?>

            </tbody>
        </table>
        <div class="table-footer">
            <div class="table-footer-child"><span>Total number of messages</span><button class="go-button"><?php echo $total_rows?></button></div>
            <div class="table-footer-child">
                <div class="pagination">
                    <?php echo $pagination;?>
                </div>
            </div>
        </div>
    </div>
</div>