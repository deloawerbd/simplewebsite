<!DOCTYPE html>
<html lang="en" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-family: sans-serif;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;font-size: 10px;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">

<head style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">

    <meta charset="utf-8" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
    <meta name="description" content="" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <meta name="author" content="" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">

    <title style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">BONAMI BD</title>
    <link rel="shortcut icon" href="http://typochat.com/assets/img/logo/favicon.ico" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <link href="http://typochat.com/assets/font-awesome-4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin: 0;font-family: Open Sans;font-size: 15px;line-height: 24px;color: #222222;background-color: #fff;text-align: justify;">


<!--Terms and Condition-->

<section id="email_notification" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 20px 0;">


    <div class="container" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;max-width: none !important;width: 1170px !important;">


        <div class="row" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;">

            <div class="col-xs-8 col_email_noti" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;float: none;width: 63.10%;display: block;margin-left: auto;margin-right: auto;">

                <div class="email_noti_con" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">


                    <div class="email_noti_body" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding: 50px;border-top: 1px solid #222222;border-right: 1px solid #222222;border-left: 1px solid #222222;">
                        <img src="<?php echo base_url()?>assets/img/logo/logo-text.jpg" width="280" alt="logo" style="margin-left: 28%;margin-bottom: 10%; margin-top: -7%;" />

                        <div class="email_noti_body_main" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                            <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-weight:600;display: block;padding: 10px 0px;">Dear Mr. Faisal,</span>

                            <p style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;orphans: 3;widows: 3;margin: 0 0 10px;"><?php echo $message;?></p>
                            <br style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                            <span class="en_body_2" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">Sincerely,</span>

                            <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 10px 0px;font-weight: 600;"><?php echo $name;?></span>
                            <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 0px 0px;font-weight: 600;"><?php echo $email;?></span>
                            <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 0px 0px;font-weight: 600;"><?php echo $mobile;?></span>

                        </div>
                    </div>

                    <div class="email_noti_footer" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                        <div class="col_logo_footer" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;background: #222222; display: block;display: table-caption; width: 59%;">
                            <div class="container footer_container" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;max-width: none !important;width: 1170px !important;">

                                <div class="row" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;">

                                    <div class="col-xs-4 col-xs-4_en_copyright" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;float: left;width: 33.33333333%;padding: 30px 40px;">
                                        <span style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;color: #fff;font-size: 11px;">Copyright <i class="fa fa-copyright" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;"></i> 2017 BONAMI BD, All Rights Reserved.</span>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </div>



                </div>


            </div>

        </div>
    </div>


</section>

</body>

</html>
