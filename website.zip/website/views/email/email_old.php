<!DOCTYPE html>
<html lang="en" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-family: sans-serif;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;font-size: 10px;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">

<head style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">

    <meta charset="utf-8" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
    <meta name="description" content="" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <meta name="author" content="" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">

    <title style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">AITSolutionbd</title>
    <link rel="shortcut icon" href="http://typochat.com/assets/img/logo/favicon.ico" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
    <link href="http://typochat.com/assets/font-awesome-4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin: 0;font-family: Open Sans;font-size: 15px;line-height: 24px;color: #222222;background-color: #fff;text-align: justify;">


<!--Terms and Condition-->

<section id="email_notification" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 20px 0;">


    <div class="container" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;max-width: none !important;width: 1170px !important;">


        <div class="row" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;">

            <div class="col-xs-8 col_email_noti" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;float: none;width: 66.66666667%;display: block;margin-left: auto;margin-right: auto;">

                <div class="email_noti_con" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">

                    <div class="email_noti_header" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                        <img class="img-responsive" src="http://aitsolutionbd.com/assets/images/logo/email-header.png" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;border: 0;vertical-align: middle;page-break-inside: avoid;display: block;max-width: 100% !important;height: auto;">
                    </div>

                    <div class="email_noti_body" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding: 50px;border-right: 1px solid #222222;border-left: 1px solid #222222;">
                        <h4 style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-weight: 600;line-height: 1.1;color: inherit;margin-top: 10px;margin-bottom: 10px;font-size: 18px;">Customer Order Information</h4>

                        <div class="email_noti_body_main" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                            <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-weight:600;display: block;padding: 10px 0px;">Dear <?php echo $email;?>,</span>

                            <p style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;orphans: 3;widows: 3;margin: 0 0 10px;">We have received your order. We are really proud to be with you.
                                We will try our best to fulfil your need.</p>

                            <ul style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-top: 0;margin-bottom: 10px;">

                                <li style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                                    <p> <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 10px 0px;font-weight: 600;">Information you provided</span></p>
                                    <p> Order date : <?php echo $date_added;?></p>
                                    <p> Service    : Website design & development</p>
                                    <p> Name       : <?php echo $client_name;?></p>
                                    <p> Email      : <?php echo $email;?></p>
                                    <p> Mobile     : <?php echo $mobile;?> </p>
                                </li>

                                <br style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                          </ul>

                            <p style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;orphans: 3;widows: 3;margin: 0 0 10px;">
                                <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 10px 0px;font-weight: 600;">
                                    If Urgent contact given below
                                </span>
                                </p>
                            <ul style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-top: 0;margin-bottom: 10px;">
                                <li style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                                    <p><span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 10px 0px;font-weight: 600;">For email contact</span></p>
                                    <p> Sales       : sales@aitsolutionbd.com</p>
                                    <p> Information : info@aitsolutionbd.com</p>
                                    <p> Support     : support@aitsolutionbd.com</p>
                                    <p> Programmer  : deloawer@aitsolutionbd.com </p>
                                </li>
                                <li style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                                    <p><span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 10px 0px;font-weight: 600;">Hotline</span></p>
                                    <p> +8801717999410</p>
                                    <p> +8801682150628</p>
                                </li>
                                <br style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">

                            </ul>

                            <span class="en_body_2" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">Sincerely,</span>

                            <span class="en_body_1" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;display: block;padding: 10px 0px;font-weight: 600;">AITSolutionbd  Management</span>


                        </div>
                    </div>

                    <div class="email_noti_footer" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;">
                        <div class="col_logo_footer" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;background: #222222; display: block;display: table-caption; width: 100%;">
                            <div class="container footer_container" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;max-width: none !important;width: 1170px !important;">

                                <div class="row" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;">

                                    <div class="col-xs-4 col-xs-4_en_copyright" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;float: left;width: 33.33333333%;padding: 30px 40px;">
                                        <span style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;color: #fff;font-size: 11px;">Copyright <i class="fa fa-copyright" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;"></i> 2016 aitsolutionbd, All Rights Reserved.</span>
                                    </div>

                                    <div class="col-xs-4" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;float: left;width: 33.33333333%;">
                                        <div class="footer_logo footer_logo_en" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;padding: 20px 0px;">
                                            <img src="http://aitsolutionbd.com/assets/images/logo/logo-3.png" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;border: 0;vertical-align: middle;page-break-inside: avoid;width:244px;display: block;margin-left: auto;margin-right: 124px !important;margin-bottom: 10px;max-width: 100% !important;">
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </div>



                </div>


            </div>

        </div>
    </div>


</section>

</body>

</html>
