<!doctype html>
<html class="no-js" lang="">

<head>
    <!-- Basic page needs
    ============================================ -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>BONAMI BD</title>
    <meta name="description" content="">
    <!-- Mobile specific metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url()?>assets/img/favicon-32x32.png">
    <!--All Fonts  Here -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Bitter:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- ALL CSS FILES HERE -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom-style.css">
    <!-- font-awesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
    <!-- fancybox CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/fancybox/jquery.fancybox.css">
    <!--bxslider CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery.bxslider.min.css">
    <!-- owl.carousel CSS-->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/owl.carousel.css">
    <!-- owl.carousel transitions CSS-->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/owl.transitions.css">
    <!-- owl.theme CSS-->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/owl.theme.css">
    <!-- nivo slider CSS  -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/custom-slider/css/nivo-slider.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo base_url()?>assets/custom-slider/css/preview.css" type="text/css" media="screen" />
    <!-- animate CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/animate.css">
    <!-- jquery-ui-->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/jquery-ui.css">
    <!-- css for mobile menu-->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/mobile_menu.min.css">
    <!-- normalize CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/normalize.css">
    <!-- main CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/main.css">
    <!-- style CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/style.css">

    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/custom-style.css">
    <!-- responsive CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/responsive.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />

    <!-- modernizr js -->
    <script src="<?php echo base_url()?>assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body class="home-3 home-4">
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!-- start preloader -->
<div id="loader-wrapper">
    <div class="logo"></div>
    <div id="loader">
    </div>
</div>
<!-- end preloader -->
<!-- header area start -->
<div class="header-top">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-4 col-lg-4">
               <div class="row">
                   <div class="col-sm-12 col-md-12 col-lg-12">
                       <div class="logo-area" style="margin-top:10px;">
                           <a href="<?php echo base_url()?>"  style="display: inline-block" >
                               <img src="<?php echo base_url()?>assets/img/logo/logo-text.jpg" width="325" alt="logo" height="100"/>
                           </a>
                       </div>
                   </div>

               </div>

            </div>
            <div class="col-sm-12 col-md-2 col-lg-2" style="padding-left: 0px; padding-right: 0px">
             &nbsp;<img src="<?php echo base_url()?>assets/img/freesample.png" width="105" height="105">
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6 top-message">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12" style="padding-left: 0px; padding-right: 0px">
                        <marquee direction = "left" class="top-marquee"><h5>GARMENTS EXPORTER , MANUFACTURER & GLOBAL SOURCING COMPANY</h5></marquee>
                    </div>

                </div>
                <div class="row row-custome-head">
                    <div class="col-sm-6 col-md-3 col-lg-3" style="padding-left: 0px; padding-right: 0px" >
                        <i class="glyphicon glyphicon-envelope"></i>&nbsp;
                        <a class="top-mail-skp" href="mailto:info@bonamibd.com" >info@bonamibd.com</a>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3" style="padding-left: 0px; padding-right: 0px; text-align: center" >
                        <img src="<?php echo base_url()?>assets/img/tnt.jpg" height="15" width="15">+8802-55091833
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3" style="padding-left: 0px; padding-right: 0px" >
                        <i class="glyphicon glyphicon-earphone"></i>+8801874535340
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3" style="padding-left: 0px; padding-right: 0px" >
                        <i class="fa fa-skype"></i><a href="skype:bonami33?call" class="top-mail-skp" >bonami33</a>
                    </div>

                </div>

            </div>


        </div>
    </div>
</div>
<!-- main menu area start  -->
<div class="main-menu-area ">
    <div class="container">
        <div class="row">
            <div class="col-xs-1 col-sm-2 col-md-1 col-lg-1">
                <a href="<?php echo base_url()?>"  style="display: inline-block" >
                    <img src="<?php echo base_url()?>assets/img/logo/logo.jpg" alt="logo" />
                </a>
            </div>
            <div class="col-xs-11 col-sm-10 col-md-11 col-lg-11">
                <nav class="nav-menu-main">
                    <ul>
                        <li class=""><a href="<?php echo base_url()?>"><i class="fa fa-lg fa-home"></i>Home</a></li>
                        <li class=""><a href="<?php echo base_url('product/menswear')?>">Men's</a></li>
                        <li><a href="<?php echo base_url('product/ladieswear')?>">Women's</a></li>
                        <li><a href="<?php echo base_url('product/kidswear')?>">Kid's</a></li>
                        <li><a href="<?php echo base_url('product/fashionwear')?>">Fashion</a></li>
                        <li><a href="<?php echo base_url('product/sportswear')?>">Sports</a></li>
                        <li><a href="<?php echo base_url('product/workwear')?>">Work wear</a></li>
                        <li><a href="<?php echo base_url('product/import')?>">Import gallery</a></li>
                        <li><a href="<?php echo base_url('about-us')?>" >About us</a></li>
                        <li><a href="<?php echo base_url('teams')?>" >Team</a></li>
                        <li><a href="<?php echo base_url('contact')?>" >Contact</a></li>

                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- main menu area end  -->
<!-- search area start  -->
<div class="nk-search-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="menu-cat-area">
                    <h3 class="nk-module-title"><span>PRICE QUOTATION</span></h3>
                    <div class="nk-all-items">
                        <div class="sp-module-content">
                            <!-- treeview -->
                            <div class="vina-treeview-virtuemart" id="vina-treeview-virtuemart93">

                                <ul class="level0 treeview">
                                    <li class="sp-menu-item sp-menu-item-hitarea" ><a href="javascript:void (0)">Knit</a>

                                        <ul class="level0 treeview sub-menu-bnf">
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/t-shirt-polo-shirt')?>">T-shirt & Polo shirt</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/hoodie-jacket')?>"> Hoodie & Jacket</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/trouser-leggings')?>">Trouser & Leggings</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/sports-swim-wear')?>">Sports & Swim wear</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/kids-baby-wear')?>">Kid's & Baby wear</a></li>
                                        </ul>
                                    </li>
                                    <li class="sp-menu-item" ><a href="javascript:void (0)">Woven</a>
                                        <ul class="level0 treeview sub-menu-bnf">
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/denim-cargo-pant')?>">Denim & Cargo pant</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/trouser-overall-hv')?>">Trouser & Overall - HV</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/windbreaker-out-wear')?>">Windbreaker & Out wear -HV</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/shirt-blouse')?>">Shirt & Blouse</a></li>
                                            <li class="sp-menu-item" ><a href="<?php echo base_url('product/apron-vest')?>">Apron & Vest</a></li>
                                        </ul>

                                    </li>
                                    <li class="sp-menu-item" ><a href="<?php echo base_url('product/sweater')?>">Sweater</a></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-7 col-lg-7">
                <div class="form-group">
                 <select class="select-nksearch form-control" id="search-menu">
                        <option >Search Item</option>
                        <option value="t-shirt-polo-shirt">T-shirt & Polo shirt</option>
                        <option value="hoodie-jacket" >Hoodie & Jacket</option>
                        <option value="trouser-leggings">Trouser & Leggings</option>
                        <option value="sports-swim-wear">Sports & Swim wear</option>
                        <option value="kids-baby-wear">Kid's & Baby wear</option>
                        <option value="denim-cargo-pant" >Denim & Cargo pant</option>
                        <option value="trouser-overall-hv">Trouser & Overall - HV</option>
                        <option value="windbreaker-out-wear">Windbreaker & Out wear -HV</option>
                        <option value="shirt-blouse">Shirt & Blouse</option>
                        <option value="apron-vest">Apron & Vest</option>
                        <option value="sweater">Sweater</option>
                    </select>
                </div>

            </div>
            <div class="col-xs-6 col-sm-6 col-md-2 col-lg-2">
                <a class="btn btn-default" href="<?php echo base_url()?>assets/files/portfolio.pdf" download><i class="glyphicon glyphicon-download-alt"></i>&nbsp;Profile</a>
            </div>
        </div>
    </div>
</div>
<!-- main menu area end  -->
<!-- mobile-menu-area start -->
<!--<div class="mobile-menu-area">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-md-12">-->
<!--                <div class="mobile-menu">-->
<!--                    <nav id="dropdown">-->
<!--                        <ul>-->
<!--                            <li><a href="index.html">Home</a>-->
<!--                                <ul>-->
<!--                                    <li><a href="index.html">Home 1</a></li>-->
<!--                                    <li><a href="index-2.html">Home 2</a></li>-->
<!--                                    <li><a href="index-3.html">Home 3</a></li>-->
<!--                                    <li><a href="index-4.html">Home 4</a></li>-->
<!--                                    <li><a href="index-5.html">Home 5</a></li>-->
<!--                                    <li><a href="index-6.html">Home 6</a></li>-->
<!--                                </ul>-->
<!--                            </li>-->
<!--                            <li><a href="about-us.html">About Us</a></li>-->
<!--                            <li><a href="blog.html">Blog</a></li>-->
<!--                            <li><a href="portfolio.html">Portfolio</a></li>-->
<!--                            <li><a href="#">Pages</a>-->
<!--                                <ul>-->
<!--                                    <li><a href="blog-post.html">blog post page</a></li>-->
<!--                                    <li><a href="cart.html">cart page</a></li>-->
<!--                                    <li><a href="checkout.html">checkout page</a></li>-->
<!--                                    <li><a href="login.html">login page</a></li>-->
<!--                                    <li><a href="shop.html">shop page</a></li>-->
<!--                                    <li><a href="single-product.html">single product page</a></li>-->
<!--                                    <li><a href="wishlist.html">wishlist</a></li>-->
<!--                                </ul>-->
<!--                            </li>-->
<!--                            <li><a href="corporate.html">Corporate</a></li>-->
<!--                            <li><a href="contact.html">Contact Us</a></li>-->
<!--                        </ul>-->
<!--                    </nav>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<!-- mobile-menu-area end -->
<!-- slider area start -->
<div class="home-4-slider-area" style="<?php echo ($slider_show ===TRUE) ? 'display:block' : 'display:none';?>">
    <div class="h4-slider">
        <!-- HOME SLIDER -->
        <div class="slider-wrap">
            <!-- slider -->
            <div class="slider-area">
                <div class="bend niceties preview-2">
                    <div id="ensign-nivoslider" class="slides">
                        <img src="<?php echo base_url()?>assets/img/slider/new/fashion-wear.png" alt="" title="#slider-direction-1"  />
                        <img src="<?php echo base_url()?>assets/img/slider/new/kids-wear.png" alt="" title="#slider-direction-2"  />
                        <img src="<?php echo base_url()?>assets/img/slider/new/mens-wear.png" alt="" title="#slider-direction-3"  />
                        <img src="<?php echo base_url()?>assets/img/slider/new/sports-wear.png" alt="" title="#slider-direction-4"  />
                        <img src="<?php echo base_url()?>assets/img/slider/new/womens-wear.png" alt="" title="#slider-direction-5"  />
                        <img src="<?php echo base_url()?>assets/img/slider/new/work-wear.png" alt="" title="#slider-direction-6"  />
                    </div>
                    <!-- direction 1 -->
                    <div id="slider-direction-1" class="t-cn slider-direction ">
                        <div class="slider-content t-lfl s-tb slider-1 slid-2 ">
<!--                            <div class="title-container s-tb-c title-compress">-->
<!--                                <h2 class="title2" > 2017 collection  </h2>-->
<!--                                <h1 class="title1">Men’s style </h1>-->
<!--                                <h2 class="title2" >Claritas est etiam processus dynam </h2>-->
<!--                            </div>-->
                        </div>
                    </div>
                    <!-- direction 2 -->
                    <div id="slider-direction-2" class="t-cn slider-direction">
                        <div class="slider-content t-lfl s-tb slider-1 ">
<!--                            <div class="title-container s-tb-c title-compress">-->
<!--                                <h2 class="title2" > 2017 collection  </h2>-->
<!--                                <h1 class="title1">Men’s style </h1>-->
<!--                                <h2 class="title2" >Claritas est etiam processus dynam </h2>-->
<!--                            </div>-->
                        </div>
                    </div>
                    <div id="slider-direction-3" class="t-cn slider-direction">
                        <div class="slider-content t-lfl s-tb slider-1 ">
<!--                            <div class="title-container s-tb-c title-compress">-->
<!--                                <h2 class="title2" > 2017 collection  </h2>-->
<!--                                <h1 class="title1">Men’s style </h1>-->
<!--                                <h2 class="title2" >Claritas est etiam processus dynam </h2>-->
<!--                            </div>-->
                        </div>
                    </div>
                    <div id="slider-direction-4" class="t-cn slider-direction">
                        <div class="slider-content t-lfl s-tb slider-1 ">
<!--                            <div class="title-container s-tb-c title-compress">-->
<!--                                <h2 class="title2" > 2017 collection  </h2>-->
<!--                                <h1 class="title1">Men’s style </h1>-->
<!--                                <h2 class="title2" >Claritas est etiam processus dynam </h2>-->
<!--                            </div>-->
                        </div>
                    </div>
                    <div id="slider-direction-5" class="t-cn slider-direction">
                        <div class="slider-content t-lfl s-tb slider-1 ">
<!--                            <div class="title-container s-tb-c title-compress">-->
<!--                                <h2 class="title2" > 2017 collection  </h2>-->
<!--                                <h1 class="title1">Men’s style </h1>-->
<!--                                <h2 class="title2" >Claritas est etiam processus dynam </h2>-->
<!--                            </div>-->
                        </div>
                    </div>
                    <div id="slider-direction-6" class="t-cn slider-direction">
                        <div class="slider-content t-lfl s-tb slider-1 ">
<!--                            <div class="title-container s-tb-c title-compress">-->
<!--                                <h2 class="title2" > 2017 collection  </h2>-->
<!--                                <h1 class="title1">Men’s style </h1>-->
<!--                                <h2 class="title2" >Claritas est etiam processus dynam </h2>-->
<!--                            </div>-->
                        </div>
                    </div>

                </div>
            </div>
            <!-- slider end-->
        </div>
        <!-- END HOME SLIDER -->
    </div>
</div>
<!-- slider area end -->
<!-- header area end -->
