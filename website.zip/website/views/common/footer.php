
<!-- Brand area start -->
<div class="brand-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="home3-wrapper">
                    <h3 class="sp-module-title"><span>Brand &amp; Clients</span></h3>
                </div>
            </div>
            <div class="clear"></div>
            <div class="all-brand singal-p">
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/1.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/2.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/2-2.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/3.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/4.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/5.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/6.jpg" alt="" /> </a>
                    </div>
                </div> <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/7.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/8.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/9.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/10.jpg" alt="" /> </a>
                    </div>
                </div>
                <div class="singal_brand">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <a href="#"> <img src="<?php echo base_url()?>assets/img/brand/11.jpg" alt="" /> </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- footer top area start -->


<section class="custome-text-div" >
    <div class="container bottom-text-div">
        <div class="row">
            <div class="col-sm-12 col-md-4 col-lg-4 sp-bottom11" id="sp-bottom1">
                <h6 class="bottom-text-h6">COMPANY AT A GLANCE</h6>
               <p class="custom-text-align" ><b class="green-cls">BONAMI BD</b>. <b class="red-cls" >Global Fashion</b> Is one of the reliable BUYING HOUSE, exporter & manufacturer of Knit, Woven, Denim, Sweater, Loom products (Lunge) & Handicrafts in Bangladesh has launched in 2009 with highly qualified, skilled and experienced people. The management and the employees of the company have attained vast experience dealing with different buyers & brands for long since through their career. The company, in order to emblem modern fashion & technology being join in a manufacturing  project.</p>
                <p class="custom-text-align" ><b class="green-cls">BONAMI BD</b> is pledged to quote best price, provide best quality and supply goods in time to survive in the highly competitive market having excellent relationship with the clients all over the world. We respect buyers demand as we want to establish long run business and try our best to satisfy the client's want considering our self as a customer. We impose latest manufacturing technologies and efficiency to maintain international standard and quality to keep abreast of the time.</p>

            </div>
            <div class="col-sm-12 col-md-4 col-lg-4 sp-bottom12" id="sp-bottom2">
               <h6 class="bottom-text-h6" >QUALITY CONTROL </h6>
                <p class="custom-text-align">We have well trained and highly motivated quality teams who ensure quality in every step of productions. We have also innovative production planning and management team to maintain production schedule and lead time. Our team follows knitting, dyeing, check fabrics component, color fastness, GSM and shrinkage as per the buyer requirements maintaining international standard and permit to cut fabrics with approval pattern. They also trail the quality of trims and accessories, follow the sewing, finishing and packing to be ensured the quality step by step and inform day to day report to the buyer.</p>
                <p class="custom-text-align">Ours quality inspectors check the goods piece to piece and follow the world wide methods:-
                    Inline inspection—Bulk inspection (1st bulk/2nd bulk…) --- Pre-final inspection —Final Inspection.
                    When all the goods are ready, we arrange final inspection done by our inspection team or third party on the basis of AQL and send goods with the consent of buyer.
                </p>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-4 sp-bottom123" id="sp-bottom2">
                <h6 class="bottom-text-h6" >BONAMI INTERNATIONAL</h6>
                 <p class="custom-text-align" >BONAMI International is an integral part of <b class="green-cls">BONAMI BD</b> established in 2012 as a sister concern of <b class="green-cls">BONAMI BD</b> in order to expand his business through the world. Having realized that for the country well being one shouldn't  have depended only in Export but they have to import some necessary items that can meet the demand for the time being. Hence, BONAMI international recently starting import Lather bag, Belt, Toes , Fashion/Mobile Accessories & Trendy Fabris to catch the BD local market along with others articles. Our aim is to introduce new foreign products that can meet the needs of time for urban & rural area specially who stay remote zone and beyond the touch of modern civilization.</p>
            </div>

        </div>
    </div>
</section>


<section id="sp-bottom-1">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-3" id="sp-bottom1">
                <div class="sp-column ">
                    <div class="sp-module image-holder">
                        <h3 class="sp-module-title sp-module-title-new sp-module-title-bottom"><span>Update News</span></h3>
                        <div class="sp-module-content">
                            <div class="custom">
                                <div class="footer-static-content" style="background-color:#eaeaea; opacity: .8 " >
                                    <marquee direction = "up" scrolldelay="150">Our manufacturing units are OEKOTEX & BSCI Certified and ACCORD verified</marquee>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-9" id="sp-bottom2">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <h3 class="sp-module-title sp-module-title-cr sp-module-title-bottom"><span>CERTIFICATES</span></h3>
                        <div class="sp-module-content">
                            <div class="custom">
                                <div class="row">
                                    <div class="col-xs-6  col-sm-2 col-md-2 image-holder custome-image-holder">
                                        <div class="moduletable">
                                           <img src="<?php echo base_url('assets/img/bottom-image/1.jpg')?>" alt="Image ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6  col-sm-2 col-md-2 image-holder custome-image-holder">
                                        <div class="moduletable">
                                            <img src="<?php echo base_url('assets/img/bottom-image/2.jpg')?>" alt="Image ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6  col-sm-2 col-md-2 image-holder custome-image-holder">
                                        <div class="moduletable">
                                            <img src="<?php echo base_url('assets/img/bottom-image/3.jpg')?>" alt="Image ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6  col-sm-2 col-md-2 image-holder custome-image-holder custome-image-holder-1 " style="width: 18.666% !important;">
                                        <div class="">
                                            <img src="<?php echo base_url('assets/img/bottom-image/4.jpg')?>" alt="Image ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6  col-sm-2 col-md-2 image-holder image-holder-r custome-image-holder custome-image-holder-1" style="width: 18.666% !important;" >
                                        <div class="">
                                            <img src="<?php echo base_url('assets/img/bottom-image/5.gif')?>" alt="Image ">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="sp-bottom-2">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-2 sp-bottomcontact">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <h5 class="sp-module-title-2"><span>Page view</span></h5>
                        <div class="sp-module-content">
                            <div class="custom">
                                <div class="t-bottom-content t-bottom-content-menu">
                                    <p class="email">
                                        <a href="<?php echo base_url()?>">Home</a>
                                    </p>
                                    <p class="email">
                                     <a href="<?php echo base_url('about-us')?>">About Us</a>
                                    </p>
                                    <p class="email">
                                        <a href="<?php echo base_url('contact')?>">Contact</a>
                                    </p>
                                    <p class="email">
                                        <a href="<?php echo base_url('teams')?>">Team</a>
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-md-3 sp-bottomcontact">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <h5 class="sp-module-title-2"><span>General Contact</span></h5>
                        <div class="sp-module-content">
                            <div class="custom">
                                <div class="t-bottom-content">
                                    <p class="email">
                                        <span class="ft-content"><a href="mailto:info@bonamibd.com" class="ft-content" ><i class="glyphicon glyphicon-envelope"></i>&nbsp;info@bonamibd.com</a>
                                            <br><a href="mailto:bonamibd@hotmail.com" class="ft-content"><i class="glyphicon glyphicon-envelope"></i>&nbsp;bonamibd@hotmail.com</a></span><br>
                                        <span class="ft-content"><a href="skype:bonami33?call"><i class="fa fa-skype"></i>&nbsp;bonami33</a><br>
                                        <span class="ft-content"><i class="glyphicon glyphicon-earphone"></i>&nbsp;+8801874535340</span>
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 sp-bottomcontact">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <h5 class="sp-module-title-2"><span>Re/Office </span></h5>
                        <div class="sp-module-content">
                            <div class="custom">
                                <div class="t-bottom-content">
                                    <p class="adress">
                                        <span class="ft-content">Plot:350/A , Bashundhara , Baipial	</span>
                                        <span class="ft-content">Ashulia , Savar , Dhaka-1349, </span>
                                        <span class="ft-content">Bangladesh	</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 sp-bottomcontact">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <h5 class="sp-module-title-2"><span>Dhaka Office</span></h5>
                        <div class="sp-module-content">
                            <div class="custom">
                                <div class="t-bottom-content">
                                    <p class="adress">
                                        <span class="ft-content">House : 41 , Road : 03 , Sector:10</span>
                                        <span class="ft-content">Uttara , Dhaka-1230, </span>
                                        <span class="ft-content"> Bangladesh</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-1 sp-bottomcontact">
                <div class="sp-column ">
                    <div class="sp-module ">
                        <h5 class="sp-module-title-2"><span>Link</span></h5>
                        <div class="sp-module-content">
                            <div class="custom">
                                <p><a href="https://www.facebook.com/bonamibdf" target="_blank"><i class="fa fa-lg fa-facebook"></i></a></li></p>
                                <p><a href="https://twitter.com/bonami33" target="_blank"><i class="fa fa-lg fa-twitter"></i></a></li></p>
                                <p><a href="http://bd.linkedin.com/in/bonami" target="_blank"><i class="fa fa-lg fa-linkedin"></i></a></li></p>
                                <p><a href="http://www.instagram.com/bonami_bd" target="_blank"><i class="fa fa-lg fa-instagram"></i></a></li></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<footer id="sp-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-6">
                <p>Copyright &copy; 2017 <a  href="#" target="_blank">BONAMIBD</a> All Rights Reserved</p>
            </div>
            <div class="col-sm-6 col-md-6">
                <div class="payment-logo">
                    <img src="<?php echo base_url()?>assets/img/payment.png" alt="" />
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer top area end -->

<!-- Modal -->
<!--<div class="modal fade" id="myModal" role="dialog">-->
<!--    <div class="modal-dialog">-->
<!---->
<!--        <!-- Modal content-->-->
<!--        <div class="modal-content">-->
<!--            <div class="modal-header">-->
<!--                <button type="button" class="close" data-dismiss="modal">&times;</button>-->
<!--                <h4 class="modal-title">Product Description</h4>-->
<!--            </div>-->
<!--            <div class="modal-body">-->
<!--                <p>-->
<!--                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been-->
<!--                    the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of-->
<!--                type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the-->
<!--                leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with-->
<!--                the release of Letraset sheets containing Lorem Ipsum passages,-->
<!--                    and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>-->
<!--            </div>-->
<!--            <div class="modal-footer">-->
<!--                <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>-->
<!--            </div>-->
<!--        </div>-->
<!---->
<!--    </div>-->
<!--</div>-->

<!-- ALL JS FILES HERE -->
<!-- Modal -->
<!--<div class="modal left fade" id="admodal" style="display: block">-->
<!--    <div class="modal-dialog" role="document">-->
<!--        <div class="modal-content">-->
<!---->
<!--            <div class="modal-header">-->
<!--                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
<!--                <h4 class="modal-title" id="myModalLabel">Top Rated Product</h4>-->
<!--            </div>-->
<!---->
<!--            <div class="modal-body">-->
<!--                <p>-->
<!--                    <img src="--><?php //echo base_url('assets/product-picture/home/8.jpg');?><!--" height="200">-->
<!--                </p>-->
<!--                <div class="product-rating">-->
<!--                    <div class="ratingbox" title=" Rating: 3/5">-->
<!--                        <div style="width:50px" class="stars-orange"></div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="modal-footer">-->
<!--              <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>-->
<!--            </div>-->
<!---->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<!---->
<!--<!-- Modal -->
<!--<div class="modal right fade" id="" style="display: block" >-->
<!--    <div class="modal-dialog" role="document">-->
<!--        <div class="modal-content">-->
<!---->
<!--            <div class="modal-header">-->
<!--                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
<!--                <h4 class="modal-title" id="myModalLabel2">Most Popular Product</h4>-->
<!--            </div>-->
<!---->
<!--            <div class="modal-body">-->
<!--                <p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.-->
<!--                </p>-->
<!--            </div>-->
<!--                        <div class="modal-footer">-->
<!--                            <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>-->
<!--                        </div>-->
<!---->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->



<!-- jquery js -->
<script src="<?php echo base_url()?>assets/js/vendor/jquery-1.11.3.min.js"></script>
<!-- price_slider js -->
<script src="<?php echo base_url()?>assets/js/price_slider.js"></script>
<!-- bootstrap js -->
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
<!-- owl.carousel.min js -->
<script src="<?php echo base_url()?>assets/js/owl.carousel.min.js"></script>
<!-- slicknav js -->
<script src="<?php echo base_url()?>assets/js/jquery.mobilemenu.js"></script>
<!-- parallax js -->
<script src="<?php echo base_url()?>assets/js/parallax.js"></script>
<!-- treeview js -->
<script src="<?php echo base_url()?>assets/js/jquery.treeview.js"></script>
<!-- jquery mixitup js -->
<script src="<?php echo base_url()?>assets/js/jquery.mixitup.min.js"></script>
<!-- jquery.scrollUp js -->
<script src="<?php echo base_url()?>assets/js/jquery.scrollUp.min.js"></script>
<!-- jquerye levatezoom js -->
<script src="<?php echo base_url()?>assets/js/jquery.elevatezoom.js"></script>
<!-- jquerye countdown js -->
<script src="<?php echo base_url()?>assets/js/countdown.js"></script>
<!-- jquery fancybox js -->
<script src="<?php echo base_url()?>assets/js/jquery.fancybox.pack.js"></script>
<!-- jquery bx-slider js -->
<script src="<?php echo base_url()?>assets/js/bx-slider.min.js"></script>
<!-- jquery.easing js -->
<script src="<?php echo base_url()?>assets/js/jquery.easing.1.3.min.js"></script>
<!-- Nivo slider js  -->
<script src="<?php echo base_url()?>assets/custom-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/custom-slider/home.js" type="text/javascript"></script>
<!-- jquery.appear js -->
<script src="<?php echo base_url()?>assets/js/jquery.appear.js"></script>
<!-- wow js -->
<script src="<?php echo base_url()?>assets/js/wow.js"></script>
<script>
    new WOW().init();
</script>
<!-- plugins js -->
<script src="<?php echo base_url()?>assets/js/plugins.js"></script>
<!-- main js -->
<script src="<?php echo base_url()?>assets/js/main.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyARIvRl7eJuEDGlSKjomaqfEkkvDCCXYgs&callback=initMap">
</script>

<script>
    function initMap() {
        var uluru = {lat: 23.872135, lng: 90.398935};
        var map = new google.maps.Map(document.getElementById('mapShow'), {
            zoom: 16,
            center: uluru
        });
        var marker = new google.maps.Marker({
            position: uluru,
            map: map
        });
    }
</script>


<script>
    $("#search-menu").select2({
        placeholder: "Search Item",
        allowClear: true
    });

    $(document).ready(function(){
        $(".quick-view-detail").click(function(){
            $("#myModal").modal('show');
        });
        $("#search-menu").change(function (e) {
            var val = $(this).val();
           window.location.href="<?php echo base_url('product/')?>"+val;
        });

        setTimeout(function (e) {
             $("#admodal").modal('show');
        }, 5000);

    });
</script>


</body>

</html>
